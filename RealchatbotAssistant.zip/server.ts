import express from 'express';
import http from 'http';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { WebSocketServer, WebSocket } from 'ws';
import { GoogleGenAI, Modality, LiveServerMessage, GenerateVideosOperation } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const server = http.createServer(app);
const PORT = Number(process.env.PORT) || 3000;

app.use(express.json({ limit: '25mb' }));

// External API keys
const GROQ_API_KEY =
  process.env.GROQ_API_KEY ||
  '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';
const OPENROUTER_API_KEY =
  process.env.OPENROUTER_API_KEY ||
  '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';
const SITE_URL =
  process.env.APP_URL ||
  'https://ais-dev-66ud52jhby3ayc3gcin6nc-129150003501.asia-southeast1.run.app';
const SITE_NAME = 'Nova AI';

// Server-side initialization of Gemini API as mandated by gemini-api skill
const apiKey = process.env.GEMINI_API_KEY;
const ai = new GoogleGenAI({
  apiKey: apiKey || '',
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

// Helper to convert frontend messages into Gemini contents
function buildGeminiContents(messages: any[]) {
  return messages.map((m: any) => {
    const parts: any[] = [];

    if (m.attachments && Array.isArray(m.attachments)) {
      for (const att of m.attachments) {
        if (att.isImage && att.dataUrl) {
          const base64Data = att.dataUrl.includes('base64,')
            ? att.dataUrl.split('base64,')[1]
            : att.dataUrl;
          parts.push({
            inlineData: {
              mimeType: att.type || 'image/jpeg',
              data: base64Data,
            },
          });
        } else if (att.textContent) {
          parts.push({
            text: `[File Attachment: ${att.name}]\n${att.textContent}`,
          });
        }
      }
    }

    if (m.content) {
      parts.push({ text: m.content });
    } else if (parts.length === 0) {
      parts.push({ text: 'Please analyze this.' });
    }

    return {
      role: m.role === 'assistant' || m.role === 'model' ? 'model' : 'user',
      parts,
    };
  });
}

// Helper to execute streaming Gemini call with Search Grounding
async function executeGeminiStream(
  res: express.Response,
  messages: any[],
  systemInstruction?: string,
  temperature = 0.7,
  model = 'gemini-3.5-flash',
  useGoogleSearch = false
) {
  if (!res.headersSent) {
    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');
    res.flushHeaders?.();
  }

  const contents = buildGeminiContents(messages);
  const config: Record<string, any> = {
    temperature: Math.max(0, Math.min(2, Number(temperature) || 0.7)),
  };

  if (systemInstruction && typeof systemInstruction === 'string' && systemInstruction.trim()) {
    config.systemInstruction = systemInstruction.trim();
  }

  // Feature 2: Use Google Search Grounding with gemini-3.5-flash
  if (useGoogleSearch) {
    config.tools = [{ googleSearch: {} }];
  }

  try {
    const responseStream = await ai.models.generateContentStream({
      model,
      contents,
      config,
    });

    let fullText = '';
    let latestGroundingMetadata: any = null;

    for await (const chunk of responseStream) {
      const text = chunk.text || '';
      const grounding = chunk.candidates?.[0]?.groundingMetadata;
      if (grounding) {
        latestGroundingMetadata = grounding;
      }

      if (text || grounding) {
        if (text) fullText += text;
        res.write(
          `data: ${JSON.stringify({
            chunk: text,
            groundingMetadata: grounding,
            done: false,
          })}\n\n`
        );
      }
    }

    res.write(
      `data: ${JSON.stringify({
        done: true,
        fullText,
        groundingMetadata: latestGroundingMetadata,
      })}\n\n`
    );
    return res.end();
  } catch (err: any) {
    console.error(`Error during streaming Gemini call (${model}):`, err);

    if (model !== 'gemini-3.1-flash-lite') {
      console.warn(`Falling back from ${model} to gemini-3.1-flash-lite...`);
      return executeGeminiStream(res, messages, systemInstruction, temperature, 'gemini-3.1-flash-lite', false);
    }

    res.write(
      `data: ${JSON.stringify({
        error: err.message || 'Error communicating with Gemini model',
        done: true,
      })}\n\n`
    );
    return res.end();
  }
}

// Helper to execute unary Gemini call with Search Grounding
async function executeGeminiUnary(
  res: express.Response,
  messages: any[],
  systemInstruction?: string,
  temperature = 0.7,
  model = 'gemini-3.5-flash',
  useGoogleSearch = false
) {
  const contents = buildGeminiContents(messages);
  const config: Record<string, any> = {
    temperature: Math.max(0, Math.min(2, Number(temperature) || 0.7)),
  };

  if (systemInstruction && typeof systemInstruction === 'string' && systemInstruction.trim()) {
    config.systemInstruction = systemInstruction.trim();
  }

  if (useGoogleSearch) {
    config.tools = [{ googleSearch: {} }];
  }

  try {
    const response = await ai.models.generateContent({
      model,
      contents,
      config,
    });

    const grounding = response.candidates?.[0]?.groundingMetadata;

    return res.json({
      id: `msg_${Date.now()}`,
      role: 'model',
      content: response.text || '',
      model,
      groundingMetadata: grounding,
      timestamp: new Date().toISOString(),
    });
  } catch (err: any) {
    console.error(`Error during unary Gemini call (${model}):`, err);

    if (model !== 'gemini-3.1-flash-lite') {
      console.warn(`Falling back unary from ${model} to gemini-3.1-flash-lite...`);
      return executeGeminiUnary(res, messages, systemInstruction, temperature, 'gemini-3.1-flash-lite', false);
    }

    return res.status(500).json({ error: err.message || 'Error processing request' });
  }
}

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    hasGroqKey: Boolean(GROQ_API_KEY),
    hasOpenRouterKey: Boolean(OPENROUTER_API_KEY),
    hasGeminiKey: Boolean(apiKey),
    defaultModel: 'gemini-3.5-flash',
    models: [
      { id: 'gemini-3.5-flash', name: 'Google Gemini 3.5 Flash (General & Search Grounding)', provider: 'Google' },
      { id: 'gemini-3.1-pro-preview', name: 'Google Gemini 3.1 Pro (Complex Reasoning & STEM)', provider: 'Google' },
      { id: 'gemini-3.1-flash-lite', name: 'Google Gemini 3.1 Flash Lite (Ultra Fast)', provider: 'Google' },
      { id: 'gemini-3.8-flash', name: 'Google Gemini 3.8 Flash (Multimodal Vision & Files)', provider: 'Google' },
      { id: 'gemini-3.8-live', name: 'Google Gemini 3.8 Live (Real-Time Voice API)', provider: 'Google' },
      { id: 'openai/gpt-4o', name: 'GPT-4o (OpenRouter Vision & Multimodal)', provider: 'OpenAI' },
      { id: 'anthropic/claude-3.5-sonnet', name: 'Claude 3.5 Sonnet (OpenRouter)', provider: 'Anthropic' },
    ],
    timestamp: new Date().toISOString(),
  });
});

// Chat completion endpoint (supports Gemini multi-turn, search grounding, attachments & resilient fallback)
app.post('/api/chat', async (req, res) => {
  const {
    messages,
    systemInstruction,
    temperature = 0.7,
    stream = true,
    model = 'gemini-3.5-flash',
    useGoogleSearch = false,
  } = req.body;

  if (!messages || !Array.isArray(messages) || messages.length === 0) {
    return res.status(400).json({ error: 'Missing or invalid messages array' });
  }

  // Check if any message contains image attachments
  const hasImages = messages.some(
    (m: any) => m.attachments && m.attachments.some((a: any) => a.isImage && a.dataUrl)
  );

  // Auto-route to gemini-3.5-flash if Google Search Grounding is requested
  let targetModel = model;
  if (useGoogleSearch) {
    targetModel = 'gemini-3.5-flash';
  } else if (hasImages && targetModel.startsWith('groq/')) {
    targetModel = 'gemini-3.8-flash';
  }

  // 1. Handle Gemini models directly (gemini-3.5-flash, gemini-3.1-pro-preview, gemini-3.1-flash-lite, gemini-3.8-flash)
  const isGeminiModel = targetModel.startsWith('gemini-');
  if (isGeminiModel && apiKey) {
    if (stream) {
      return executeGeminiStream(
        res,
        messages,
        systemInstruction,
        temperature,
        targetModel,
        Boolean(useGoogleSearch)
      );
    } else {
      return executeGeminiUnary(
        res,
        messages,
        systemInstruction,
        temperature,
        targetModel,
        Boolean(useGoogleSearch)
      );
    }
  }

  // 2. Build standard OpenAI-compatible messages array for OpenRouter / Groq
  const formattedMessages: any[] = [];
  if (systemInstruction && typeof systemInstruction === 'string' && systemInstruction.trim()) {
    formattedMessages.push({ role: 'system', content: systemInstruction.trim() });
  }

  for (const m of messages) {
    const role = m.role === 'assistant' || m.role === 'model' ? 'assistant' : 'user';
    let textContent = m.content || '';

    if (m.attachments && Array.isArray(m.attachments)) {
      for (const att of m.attachments) {
        if (att.textContent) {
          textContent += `\n\n[Attached File: ${att.name}]\n${att.textContent}`;
        }
      }
    }

    const hasMsgImages =
      m.attachments && m.attachments.some((a: any) => a.isImage && a.dataUrl);

    if (hasMsgImages) {
      const parts: any[] = [];
      if (textContent) parts.push({ type: 'text', text: textContent });
      for (const att of m.attachments) {
        if (att.isImage && att.dataUrl) {
          parts.push({
            type: 'image_url',
            image_url: { url: att.dataUrl },
          });
        }
      }
      formattedMessages.push({ role, content: parts });
    } else {
      formattedMessages.push({ role, content: textContent });
    }
  }

  const isGroq = targetModel.startsWith('groq/') || targetModel.includes('llama');
  const targetUrl = isGroq
    ? 'https://api.groq.com/openai/v1/chat/completions'
    : 'https://openrouter.ai/api/v1/chat/completions';
  const authKey = isGroq ? GROQ_API_KEY : OPENROUTER_API_KEY;
  const upstreamModel = isGroq ? targetModel.replace('groq/', '') : targetModel;

  const headers: Record<string, string> = {
    Authorization: `Bearer ${authKey}`,
    'Content-Type': 'application/json',
  };

  if (!isGroq) {
    headers['HTTP-Referer'] = SITE_URL;
    headers['X-Title'] = SITE_NAME;
  }

  try {
    const upstreamResponse = await fetch(targetUrl, {
      method: 'POST',
      headers,
      body: JSON.stringify({
        model: upstreamModel,
        messages: formattedMessages,
        temperature: Math.max(0, Math.min(2, Number(temperature) || 0.7)),
        stream: Boolean(stream),
      }),
    });

    if (!upstreamResponse.ok) {
      const errorText = await upstreamResponse.text();
      console.warn(`Upstream error, falling back to Gemini 3.5 Flash:`, errorText);
      if (apiKey) {
        if (stream) {
          return executeGeminiStream(res, messages, systemInstruction, temperature, 'gemini-3.5-flash');
        } else {
          return executeGeminiUnary(res, messages, systemInstruction, temperature, 'gemini-3.5-flash');
        }
      }
      return res.status(upstreamResponse.status).json({ error: errorText });
    }

    if (stream) {
      res.setHeader('Content-Type', 'text/event-stream');
      res.setHeader('Cache-Control', 'no-cache');
      res.setHeader('Connection', 'keep-alive');
      res.flushHeaders?.();

      if (!upstreamResponse.body) {
        res.write(`data: ${JSON.stringify({ error: 'No stream body', done: true })}\n\n`);
        return res.end();
      }

      const reader = upstreamResponse.body.getReader();
      const decoder = new TextDecoder('utf-8');
      let buffer = '';
      let fullText = '';

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n');
        buffer = lines.pop() || '';

        for (const line of lines) {
          const trimmed = line.trim();
          if (!trimmed || !trimmed.startsWith('data: ')) continue;
          const dataStr = trimmed.slice(6);
          if (dataStr === '[DONE]') continue;

          try {
            const parsed = JSON.parse(dataStr);
            const chunkText = parsed.choices?.[0]?.delta?.content || '';
            if (chunkText) {
              fullText += chunkText;
              res.write(`data: ${JSON.stringify({ chunk: chunkText, done: false })}\n\n`);
            }
          } catch {}
        }
      }

      res.write(`data: ${JSON.stringify({ done: true, fullText })}\n\n`);
      return res.end();
    } else {
      const data = await upstreamResponse.json();
      return res.json({
        id: data.id || `msg_${Date.now()}`,
        role: 'assistant',
        content: data.choices?.[0]?.message?.content || '',
        model: targetModel,
        timestamp: new Date().toISOString(),
      });
    }
  } catch (err: any) {
    console.warn(`Upstream call failed, falling back to Gemini 3.5 Flash: ${err.message}`);
    if (apiKey) {
      if (stream) {
        return executeGeminiStream(res, messages, systemInstruction, temperature, 'gemini-3.5-flash');
      } else {
        return executeGeminiUnary(res, messages, systemInstruction, temperature, 'gemini-3.5-flash');
      }
    }
    return res.status(500).json({ error: err.message || 'Internal server error' });
  }
});

// Feature 1: Create & Edit Images using gemini-3.1-flash-image-preview
app.post('/api/generate-image', async (req, res) => {
  const { prompt, image, aspectRatio = '1:1', imageSize = '1K' } = req.body;

  if (!prompt && !image) {
    return res.status(400).json({ error: 'Text prompt or starting image is required.' });
  }

  try {
    const parts: any[] = [];

    // Support image editing if image is provided
    if (image && image.data) {
      const rawBase64 = image.data.includes('base64,')
        ? image.data.split('base64,')[1]
        : image.data;
      parts.push({
        inlineData: {
          data: rawBase64,
          mimeType: image.mimeType || 'image/jpeg',
        },
      });
    }

    if (prompt && prompt.trim()) {
      parts.push({ text: prompt.trim() });
    }

    const response = await ai.models.generateContent({
      model: 'gemini-3.1-flash-image-preview',
      contents: { parts },
      config: {
        imageConfig: {
          aspectRatio: aspectRatio || '1:1',
          imageSize: imageSize || '1K',
        },
      },
    });

    let imageUrl = '';
    let textDescription = '';

    if (response.candidates?.[0]?.content?.parts) {
      for (const part of response.candidates[0].content.parts) {
        if (part.inlineData) {
          imageUrl = `data:${part.inlineData.mimeType || 'image/png'};base64,${part.inlineData.data}`;
        } else if (part.text) {
          textDescription += part.text;
        }
      }
    }

    if (!imageUrl) {
      return res.status(500).json({
        error: textDescription || 'No image was generated by the model.',
      });
    }

    return res.json({
      success: true,
      imageUrl,
      description: textDescription,
      prompt,
      aspectRatio,
    });
  } catch (err: any) {
    console.error('Error generating/editing image:', err);
    return res.status(500).json({
      error: err.message || 'Failed to generate image with gemini-3.1-flash-image-preview',
      requiresPaidKey:
        err.message?.includes('RESOURCE_EXHAUSTED') ||
        err.message?.includes('quota') ||
        err.message?.includes('limit: 0'),
    });
  }
});

// Feature 2: Animate Images into Video using veo-3.1-fast-generate-preview (16:9 or 9:16)
app.post('/api/generate-video', async (req, res) => {
  const { image, prompt, aspectRatio = '16:9' } = req.body;

  if (!image || !image.data) {
    return res.status(400).json({ error: 'Photo is required for Veo video animation.' });
  }

  // Ensure aspect ratio is strictly 16:9 or 9:16 per instructions
  const validAspectRatio = aspectRatio === '9:16' ? '9:16' : '16:9';
  const rawBase64 = image.data.includes('base64,')
    ? image.data.split('base64,')[1]
    : image.data;

  try {
    const operation = await ai.models.generateVideos({
      model: 'veo-3.1-fast-generate-preview',
      prompt: prompt || 'Animate this photo with natural, cinematic motion',
      image: {
        imageBytes: rawBase64,
        mimeType: image.mimeType || 'image/jpeg',
      },
      config: {
        numberOfVideos: 1,
        resolution: '720p',
        aspectRatio: validAspectRatio,
      },
    });

    return res.json({
      operationName: operation.name,
      aspectRatio: validAspectRatio,
    });
  } catch (err: any) {
    console.error('Error starting Veo video generation:', err);
    return res.status(500).json({
      error: err.message || 'Failed to start video generation with veo-3.1-fast-generate-preview',
      requiresPaidKey:
        err.message?.includes('RESOURCE_EXHAUSTED') ||
        err.message?.includes('quota') ||
        err.message?.includes('limit: 0'),
    });
  }
});

// Poll Veo video generation status
app.post('/api/video-status', async (req, res) => {
  const { operationName } = req.body;
  if (!operationName) {
    return res.status(400).json({ error: 'Missing operationName parameter.' });
  }

  try {
    const op = new GenerateVideosOperation();
    op.name = operationName;
    const updated = await ai.operations.getVideosOperation({ operation: op });
    return res.json({
      done: Boolean(updated.done),
      error: updated.error || null,
    });
  } catch (err: any) {
    console.error('Error polling video operation:', err);
    return res.status(500).json({ error: err.message || 'Failed to poll video status' });
  }
});

// Download completed Veo video stream
app.post('/api/video-download', async (req, res) => {
  const { operationName } = req.body;
  if (!operationName) {
    return res.status(400).json({ error: 'Missing operationName parameter.' });
  }

  try {
    const op = new GenerateVideosOperation();
    op.name = operationName;
    const updated = await ai.operations.getVideosOperation({ operation: op });
    const uri = updated.response?.generatedVideos?.[0]?.video?.uri;

    if (!uri) {
      return res.status(404).json({ error: 'Video URI not found or video generation incomplete.' });
    }

    const currentKey = process.env.GEMINI_API_KEY || apiKey || '';
    const videoRes = await fetch(uri, {
      headers: { 'x-goog-api-key': currentKey },
    });

    if (!videoRes.ok) {
      const errText = await videoRes.text();
      return res.status(videoRes.status).json({ error: errText || 'Failed to download video from storage' });
    }

    res.setHeader('Content-Type', 'video/mp4');
    res.setHeader('Content-Disposition', 'attachment; filename="veo-animation.mp4"');

    if (videoRes.body) {
      const reader = videoRes.body.getReader();
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        res.write(value);
      }
      res.end();
    } else {
      const buffer = await videoRes.arrayBuffer();
      res.send(Buffer.from(buffer));
    }
  } catch (err: any) {
    console.error('Error downloading video:', err);
    return res.status(500).json({ error: err.message || 'Failed to download video' });
  }
});

// Setup WebSocket Server for Gemini 3.8 Live API Voice Conversations
const wss = new WebSocketServer({ noServer: true });

server.on('upgrade', (request, socket, head) => {
  const { pathname } = new URL(request.url || '', `http://${request.headers.host || 'localhost'}`);
  if (pathname === '/live' || pathname === '/api/live') {
    wss.handleUpgrade(request, socket, head, (ws) => {
      wss.emit('connection', ws, request);
    });
  } else {
    // Let other upgrades pass through (e.g. Vite HMR if active)
  }
});

wss.on('connection', async (clientWs: WebSocket) => {
  console.log('Client connected to Live Voice WebSocket');

  let liveSession: any = null;
  let isConnected = false;

  clientWs.on('message', async (data) => {
    try {
      const message = JSON.parse(data.toString());

      // Initial setup or configuration message
      if (message.setup && !isConnected) {
        const { voiceName = 'Zephyr', systemInstruction } = message.setup;

        try {
          liveSession = await ai.live.connect({
            model: 'gemini-3.8-live',
            config: {
              responseModalities: [Modality.AUDIO],
              speechConfig: {
                voiceConfig: {
                  prebuiltVoiceConfig: {
                    voiceName: voiceName || 'Zephyr',
                  },
                },
              },
              systemInstruction:
                systemInstruction ||
                'You are a real-time conversational AI voice assistant. Speak concisely, clearly, and naturally.',
            },
            callbacks: {
              onmessage: (serverMsg: LiveServerMessage) => {
                const audio =
                  serverMsg.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
                if (audio && clientWs.readyState === WebSocket.OPEN) {
                  clientWs.send(JSON.stringify({ audio }));
                }

                if (serverMsg.serverContent?.interrupted && clientWs.readyState === WebSocket.OPEN) {
                  clientWs.send(JSON.stringify({ interrupted: true }));
                }

                const text = serverMsg.serverContent?.modelTurn?.parts?.[0]?.text;
                if (text && clientWs.readyState === WebSocket.OPEN) {
                  clientWs.send(JSON.stringify({ text }));
                }
              },
              onerror: (err) => {
                console.error('Gemini Live session error:', err);
                if (clientWs.readyState === WebSocket.OPEN) {
                  clientWs.send(JSON.stringify({ error: err.message || 'Gemini Live error' }));
                }
              },
              onclose: () => {
                console.log('Gemini Live session closed');
                if (clientWs.readyState === WebSocket.OPEN) {
                  clientWs.send(JSON.stringify({ closed: true }));
                }
              },
            },
          });

          isConnected = true;
          clientWs.send(JSON.stringify({ ready: true, model: 'gemini-3.8-live' }));
        } catch (err: any) {
          console.error('Failed to connect to Gemini Live API:', err);
          clientWs.send(
            JSON.stringify({
              error: err.message || 'Could not connect to Gemini 3.8 Live API.',
            })
          );
        }
        return;
      }

      // Stream user PCM audio chunks to Gemini Live
      if (message.audio && liveSession && isConnected) {
        liveSession.sendRealtimeInput({
          audio: {
            data: message.audio,
            mimeType: 'audio/pcm;rate=16000',
          },
        });
      }

      // Handle user text or interruption
      if (message.text && liveSession && isConnected) {
        liveSession.sendRealtimeInput({
          text: message.text,
        });
      }
    } catch (err: any) {
      console.error('Error handling WebSocket message:', err);
    }
  });

  clientWs.on('close', () => {
    console.log('Client closed Live Voice WebSocket');
    if (liveSession) {
      try {
        liveSession.close();
      } catch {}
      liveSession = null;
    }
  });
});

// Setup Vite in development or static serving in production
async function startServer() {
  const isProd = process.env.NODE_ENV === 'production';

  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  server.listen(PORT, '0.0.0.0', () => {
    console.log(`Server with Live API WebSocket running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
