import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Navigation } from './components/Navigation';
import { ChatStudio } from './components/ChatStudio/ChatStudio';
import { ImageStudio } from './components/ImageStudio/ImageStudio';
import { VideoStudio } from './components/VideoStudio/VideoStudio';
import { UsageAnalyticsModal } from './components/UsageAnalyticsModal';
import { CalendarModal } from './components/CalendarModal';
import { AppsLauncherModal } from './components/AppsLauncherModal';
import { LiveVoiceModal } from './components/LiveAudio/LiveVoiceModal';
import { LoginPage } from './components/Auth/LoginPage';
import { ThemeProvider } from './context/ThemeContext';
import { AuthProvider, useAuth } from './context/AuthContext';

function MainApp() {
  const { isLoggedIn, aiConfig } = useAuth();
  const [activeView, setActiveView] = useState<'chat' | 'image' | 'video'>('chat');
  const [activeTitle, setActiveTitle] = useState<string>(`Welcome to ${aiConfig.name || 'AI'}`);
  const [isSettingsOpen, setIsSettingsOpen] = useState<boolean>(false);
  const [isUsageOpen, setIsUsageOpen] = useState<boolean>(false);
  const [isCalendarOpen, setIsCalendarOpen] = useState<boolean>(false);
  const [isAppsOpen, setIsAppsOpen] = useState<boolean>(false);
  const [isVoiceOpen, setIsVoiceOpen] = useState<boolean>(false);
  const [newChatTrigger, setNewChatTrigger] = useState<number>(0);
  const [externalPrompt, setExternalPrompt] = useState<string>('');

  // Cross-studio workflow: send generated image directly into Veo video animator
  const [videoSourcePhoto, setVideoSourcePhoto] = useState<string | null>(null);
  const [videoSourceMime, setVideoSourceMime] = useState<string>('image/png');

  if (!isLoggedIn) {
    return <LoginPage />;
  }

  const handleAskAiToPlan = (dateStr: string) => {
    setActiveView('chat');
    setExternalPrompt(
      `Please help me plan an effective, balanced daily schedule for ${dateStr}. Include time blocks for morning focus, key tasks, breaks, and an evening wind-down.`
    );
  };

  const handleSendToVideo = (photoUrl: string, mimeType = 'image/png') => {
    setVideoSourcePhoto(photoUrl);
    setVideoSourceMime(mimeType);
    setActiveView('video');
  };

  const handleSelectApp = (appId: 'chat' | 'image' | 'video' | 'voice' | 'calendar' | 'usage') => {
    if (appId === 'chat' || appId === 'image' || appId === 'video') {
      setActiveView(appId);
    } else if (appId === 'voice') {
      setIsVoiceOpen(true);
    } else if (appId === 'calendar') {
      setIsCalendarOpen(true);
    } else if (appId === 'usage') {
      setIsUsageOpen(true);
    }
  };

  return (
    <div className="min-h-screen bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col font-sans transition-colors">
      {/* Top Header with Studio Switcher & Apps Launcher */}
      <Navigation
        activeTitle={activeTitle}
        activeView={activeView}
        onSelectView={setActiveView}
        onNewChat={() => {
          setActiveView('chat');
          setNewChatTrigger((prev) => prev + 1);
        }}
        onOpenSettings={() => setIsSettingsOpen(true)}
        onOpenUsage={() => setIsUsageOpen(true)}
        onOpenCalendar={() => setIsCalendarOpen(true)}
        onOpenApps={() => setIsAppsOpen(true)}
      />

      {/* Main Viewport with Framer Motion Page Transition */}
      <main className="flex-1 overflow-hidden relative">
        <AnimatePresence mode="wait">
          {activeView === 'chat' && (
            <motion.div
              key="view-chat"
              initial={{ opacity: 0, y: 10, scale: 0.99 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -10, scale: 0.99 }}
              transition={{ duration: 0.22, ease: 'easeOut' }}
              className="h-full w-full"
            >
              <ChatStudio
                key={newChatTrigger > 0 ? `chat-${newChatTrigger}` : 'chat-default'}
                isSettingsOpen={isSettingsOpen}
                onCloseSettings={() => setIsSettingsOpen(false)}
                onOpenSettings={() => setIsSettingsOpen(true)}
                onUpdateActiveTitle={setActiveTitle}
                externalPrompt={externalPrompt}
                onClearExternalPrompt={() => setExternalPrompt('')}
              />
            </motion.div>
          )}

          {activeView === 'image' && (
            <motion.div
              key="view-image"
              initial={{ opacity: 0, y: 10, scale: 0.99 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -10, scale: 0.99 }}
              transition={{ duration: 0.22, ease: 'easeOut' }}
              className="h-full w-full"
            >
              <ImageStudio onSendToVideoStudio={handleSendToVideo} />
            </motion.div>
          )}

          {activeView === 'video' && (
            <motion.div
              key="view-video"
              initial={{ opacity: 0, y: 10, scale: 0.99 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -10, scale: 0.99 }}
              transition={{ duration: 0.22, ease: 'easeOut' }}
              className="h-full w-full"
            >
              <VideoStudio
                initialPhotoUrl={videoSourcePhoto}
                initialMimeType={videoSourceMime}
                onClearInitialPhoto={() => setVideoSourcePhoto(null)}
              />
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Apps & Studio Suite Launcher Modal */}
      <AppsLauncherModal
        isOpen={isAppsOpen}
        onClose={() => setIsAppsOpen(false)}
        onSelectApp={handleSelectApp}
      />

      {/* Standalone Live Voice Modal triggered from Apps Suite */}
      {isVoiceOpen && (
        <LiveVoiceModal onClose={() => setIsVoiceOpen(false)} />
      )}

      {/* Daily Usage Analytics Modal */}
      {isUsageOpen && (
        <UsageAnalyticsModal onClose={() => setIsUsageOpen(false)} />
      )}

      {/* Built-in Calendar & Day Planner Modal */}
      {isCalendarOpen && (
        <CalendarModal
          onClose={() => setIsCalendarOpen(false)}
          onAskAiToPlan={handleAskAiToPlan}
        />
      )}
    </div>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <MainApp />
      </AuthProvider>
    </ThemeProvider>
  );
}
