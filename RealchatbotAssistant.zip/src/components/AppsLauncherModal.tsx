import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  X,
  MessageSquare,
  Wand2,
  Film,
  Radio,
  Globe,
  Calendar,
  BarChart3,
  Sparkles,
  ArrowRight,
  Zap,
} from 'lucide-react';

interface AppsLauncherModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectApp: (appId: 'chat' | 'image' | 'video' | 'voice' | 'calendar' | 'usage') => void;
}

interface AppCardData {
  id: 'chat' | 'image' | 'video' | 'voice' | 'calendar' | 'usage';
  name: string;
  tagline: string;
  modelBadge: string;
  icon: React.ElementType;
  gradient: string;
  borderHover: string;
  textColor: string;
  accentBg: string;
  features: string[];
}

const APPS: AppCardData[] = [
  {
    id: 'chat',
    name: 'Gemini Chat Studio',
    tagline: 'Multi-turn intelligent conversations with persona roles & history',
    modelBadge: 'gemini-3.5-flash',
    icon: MessageSquare,
    gradient: 'from-indigo-600 to-blue-600',
    borderHover: 'hover:border-indigo-500 hover:shadow-indigo-500/20',
    textColor: 'text-indigo-600 dark:text-indigo-400',
    accentBg: 'bg-indigo-500/10 text-indigo-600 dark:text-indigo-400',
    features: ['Multi-turn memory', 'System instructions', 'Search Grounding'],
  },
  {
    id: 'image',
    name: 'Image Studio',
    tagline: 'Create original art or edit existing photos with text prompts',
    modelBadge: 'gemini-3.1-flash-image-preview',
    icon: Wand2,
    gradient: 'from-purple-600 to-pink-600',
    borderHover: 'hover:border-purple-500 hover:shadow-purple-500/20',
    textColor: 'text-purple-600 dark:text-purple-400',
    accentBg: 'bg-purple-500/10 text-purple-600 dark:text-purple-400',
    features: ['Text-to-Image', 'Photo editing', '1:1, 16:9, 9:16 aspect ratios'],
  },
  {
    id: 'video',
    name: 'Veo Video Animator',
    tagline: 'Upload any photo and animate it into a cinematic video with motion prompts',
    modelBadge: 'veo-3.1-fast-generate-preview',
    icon: Film,
    gradient: 'from-amber-500 to-orange-600',
    borderHover: 'hover:border-amber-500 hover:shadow-amber-500/20',
    textColor: 'text-amber-600 dark:text-amber-400',
    accentBg: 'bg-amber-500/10 text-amber-600 dark:text-amber-400',
    features: ['Photo to Video', '16:9 landscape & 9:16 portrait', '720p HD MP4'],
  },
  {
    id: 'voice',
    name: 'Gemini Live Voice',
    tagline: 'Bidirectional, real-time voice conversations with ultra-low latency audio',
    modelBadge: 'gemini-3.8-live',
    icon: Radio,
    gradient: 'from-emerald-500 to-teal-600',
    borderHover: 'hover:border-emerald-500 hover:shadow-emerald-500/20',
    textColor: 'text-emerald-600 dark:text-emerald-400',
    accentBg: 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400',
    features: ['16kHz mic stream', '24kHz HD speech', 'Tap to interrupt'],
  },
  {
    id: 'calendar',
    name: 'AI Calendar & Planner',
    tagline: 'Daily schedule planning, time blocking & task management',
    modelBadge: 'Interactive Scheduler',
    icon: Calendar,
    gradient: 'from-blue-600 to-cyan-600',
    borderHover: 'hover:border-blue-500 hover:shadow-blue-500/20',
    textColor: 'text-blue-600 dark:text-blue-400',
    accentBg: 'bg-blue-500/10 text-blue-600 dark:text-blue-400',
    features: ['Visual schedule blocks', 'Ask AI to plan day', 'Drag & drop tasks'],
  },
  {
    id: 'usage',
    name: 'Usage Analytics',
    tagline: 'Daily token consumption metrics and everyday interactive bar chart',
    modelBadge: 'Real-time Metrics',
    icon: BarChart3,
    gradient: 'from-rose-500 to-red-600',
    borderHover: 'hover:border-rose-500 hover:shadow-rose-500/20',
    textColor: 'text-rose-600 dark:text-rose-400',
    accentBg: 'bg-rose-500/10 text-rose-600 dark:text-rose-400',
    features: ['Interactive daily bar chart', 'Estimated cost tracker', 'Live quota status'],
  },
];

export const AppsLauncherModal: React.FC<AppsLauncherModalProps> = ({
  isOpen,
  onClose,
  onSelectApp,
}) => {
  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-slate-950/70 backdrop-blur-md">
          {/* Backdrop Click */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0"
          />

          {/* Modal Container */}
          <motion.div
            initial={{ opacity: 0, scale: 0.92, y: 16 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.92, y: 16 }}
            transition={{ type: 'spring', stiffness: 350, damping: 28 }}
            className="relative w-full max-w-4xl max-h-[85vh] overflow-y-auto bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl shadow-2xl p-6 sm:p-8 flex flex-col z-10"
          >
            {/* Modal Header */}
            <div className="flex items-center justify-between pb-6 border-b border-slate-100 dark:border-slate-800 mb-6">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-indigo-600 via-purple-600 to-pink-500 text-white flex items-center justify-center shadow-lg shadow-indigo-500/25">
                  <Zap className="w-5 h-5" />
                </div>
                <div>
                  <h2 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
                    <span>Nova Apps & Studio Suite</span>
                    <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 border border-indigo-200 dark:border-indigo-800">
                      Framer Motion Powered
                    </span>
                  </h2>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    Click any application below to launch with tactile micro-interactions
                  </p>
                </div>
              </div>

              <motion.button
                whileHover={{ scale: 1.1, rotate: 90 }}
                whileTap={{ scale: 0.9 }}
                onClick={onClose}
                className="p-2 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                title="Close App Suite"
              >
                <X className="w-5 h-5" />
              </motion.button>
            </div>

            {/* Apps Grid with Framer Motion stagger & tactile click styling */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {APPS.map((app, index) => {
                const IconComponent = app.icon;
                return (
                  <motion.div
                    key={app.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{
                      delay: index * 0.05,
                      type: 'spring',
                      stiffness: 400,
                      damping: 30,
                    }}
                    whileHover={{
                      scale: 1.03,
                      y: -4,
                      transition: { duration: 0.18, ease: 'easeOut' },
                    }}
                    whileTap={{
                      scale: 0.94,
                      rotate: index % 2 === 0 ? -0.8 : 0.8,
                      transition: { duration: 0.08 },
                    }}
                    onClick={() => {
                      onSelectApp(app.id);
                      onClose();
                    }}
                    className={`group relative p-5 rounded-2xl bg-slate-50/70 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800 transition-all cursor-pointer shadow-sm hover:shadow-xl ${app.borderHover} overflow-hidden`}
                  >
                    {/* Subtle Top Gradient Accent on Hover */}
                    <div
                      className={`absolute top-0 left-0 right-0 h-1 bg-gradient-to-r ${app.gradient} opacity-0 group-hover:opacity-100 transition-opacity`}
                    />

                    {/* App Icon + Model Badge */}
                    <div className="flex items-center justify-between mb-3.5">
                      <div
                        className={`w-11 h-11 rounded-2xl bg-gradient-to-tr ${app.gradient} text-white flex items-center justify-center shadow-md group-hover:scale-110 group-hover:rotate-3 transition-transform`}
                      >
                        <IconComponent className="w-5 h-5" />
                      </div>

                      <span className="text-[10px] font-mono px-2 py-0.5 rounded-full font-medium bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 group-hover:border-current transition-colors">
                        {app.modelBadge}
                      </span>
                    </div>

                    {/* Title & Tagline */}
                    <h3 className="font-bold text-sm text-slate-900 dark:text-white group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors flex items-center justify-between">
                      <span>{app.name}</span>
                      <ArrowRight className="w-4 h-4 opacity-0 -translate-x-2 group-hover:opacity-100 group-hover:translate-x-0 transition-all text-indigo-500" />
                    </h3>

                    <p className="text-xs text-slate-500 dark:text-slate-400 mt-1.5 line-clamp-2 leading-relaxed">
                      {app.tagline}
                    </p>

                    {/* Key features bullets */}
                    <div className="mt-4 pt-3 border-t border-slate-200/60 dark:border-slate-800 flex flex-wrap gap-1">
                      {app.features.map((feat, fIdx) => (
                        <span
                          key={fIdx}
                          className="text-[9px] px-2 py-0.5 rounded-md bg-white dark:bg-slate-900 text-slate-500 dark:text-slate-400 border border-slate-200 dark:border-slate-800"
                        >
                          {feat}
                        </span>
                      ))}
                    </div>
                  </motion.div>
                );
              })}
            </div>

            {/* Bottom Bar */}
            <div className="mt-6 pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
              <span className="flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-indigo-500" />
                <span>All tools connected directly to Gemini 3.5 & Veo engines</span>
              </span>
              <span className="font-mono text-[11px]">Nova OS v3.8</span>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
