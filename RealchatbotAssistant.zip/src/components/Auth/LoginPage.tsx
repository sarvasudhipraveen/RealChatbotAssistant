import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Sparkles,
  Bot,
  User,
  Lock,
  Mail,
  ArrowRight,
  ShieldCheck,
  Sun,
  Moon,
  CheckCircle2,
  AlertCircle,
  Eye,
  EyeOff,
  Check,
  Info,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useTheme } from '../../context/ThemeContext';

const AI_NAME_SUGGESTIONS = ['Nova', 'Jarvis', 'Athena', 'Aura', 'Friday', 'Atlas', 'Echo', 'Nexus'];

export const LoginPage: React.FC = () => {
  const { login, aiConfig } = useAuth();
  const { theme, toggleTheme } = useTheme();

  const [isSignUp, setIsSignUp] = useState(true);
  const [userName, setUserName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [customAiName, setCustomAiName] = useState(aiConfig.name || 'Nova AI');
  const [hasAttemptedSubmit, setHasAttemptedSubmit] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Email / Gmail Validation Rules
  const emailTrimmed = email.trim();
  const emailHasAt = emailTrimmed.includes('@');
  const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  const isEmailValid = emailRegex.test(emailTrimmed);
  const isGmailDomain = emailTrimmed.toLowerCase().endsWith('@gmail.com');

  // Password Rules
  const passMinLength = password.length >= 8;
  const passHasUpper = /[A-Z]/.test(password);
  const passHasLower = /[a-z]/.test(password);
  const passHasNumber = /[0-9]/.test(password);
  const passHasSpecial = /[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]/.test(password);

  const passwordRulesCount = [
    passMinLength,
    passHasUpper,
    passHasLower,
    passHasNumber,
    passHasSpecial,
  ].filter(Boolean).length;

  const isPasswordValid = isSignUp
    ? passMinLength && passHasUpper && passHasLower && passHasNumber && passHasSpecial
    : password.length >= 6; // For signing in, minimum 6 characters

  // Quick helper to append @gmail.com
  const handleAppendGmail = () => {
    if (!emailTrimmed.includes('@')) {
      setEmail(`${emailTrimmed}@gmail.com`);
    } else {
      const username = emailTrimmed.split('@')[0];
      setEmail(`${username}@gmail.com`);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setHasAttemptedSubmit(true);
    setErrorMessage(null);

    // Validate email
    if (!emailTrimmed) {
      setErrorMessage('Please enter your email or Gmail address.');
      return;
    }
    if (!isEmailValid) {
      setErrorMessage('Please enter a valid email address (e.g. name@gmail.com).');
      return;
    }

    // Validate password
    if (isSignUp) {
      if (!passMinLength) {
        setErrorMessage('Password must contain at least 8 characters.');
        return;
      }
      if (!passHasUpper || !passHasLower) {
        setErrorMessage('Password must contain both uppercase and lowercase letters.');
        return;
      }
      if (!passHasNumber) {
        setErrorMessage('Password must include at least one number (0-9).');
        return;
      }
      if (!passHasSpecial) {
        setErrorMessage('Password must include at least one special character (!@#$%...).');
        return;
      }
    } else {
      if (password.length < 6) {
        setErrorMessage('Password must be at least 6 characters long.');
        return;
      }
    }

    // Success: Log in the user
    login(
      {
        name: userName.trim() || (emailTrimmed.split('@')[0] || 'User'),
        email: emailTrimmed,
      },
      customAiName.trim() || 'Nova AI'
    );
  };

  const handleQuickDemo = () => {
    login(
      {
        name: 'Alex Rivers',
        email: 'alex.rivers@gmail.com',
      },
      customAiName.trim() || 'Nova AI'
    );
  };

  // Password strength visual calculation
  const getPasswordStrengthLabel = () => {
    if (!password) return { text: 'Empty', color: 'bg-slate-200 dark:bg-slate-700', width: '0%' };
    if (passwordRulesCount <= 2) return { text: 'Weak', color: 'bg-red-500', width: '25%' };
    if (passwordRulesCount === 3) return { text: 'Fair', color: 'bg-amber-500', width: '50%' };
    if (passwordRulesCount === 4) return { text: 'Good', color: 'bg-yellow-500', width: '75%' };
    return { text: 'Strong & Secure', color: 'bg-emerald-500', width: '100%' };
  };

  const strength = getPasswordStrengthLabel();

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col justify-between p-4 md:p-8 transition-colors">
      {/* Top Header Bar */}
      <div className="flex items-center justify-between max-w-5xl mx-auto w-full">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-indigo-600 via-amber-600 to-orange-500 flex items-center justify-center text-white shadow-md shadow-indigo-600/30">
            <Sparkles className="w-4 h-4" />
          </div>
          <span className="font-bold text-base md:text-lg tracking-tight">
            {customAiName || 'Nova AI'} Studio
          </span>
        </div>

        {/* Theme Toggle */}
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={toggleTheme}
          className="flex items-center gap-1.5 px-3 py-1.5 text-xs text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white rounded-xl hover:bg-slate-200/60 dark:hover:bg-slate-900 border border-slate-200 dark:border-slate-800 transition-colors cursor-pointer"
          title="Toggle warm theme"
        >
          {theme === 'warm-espresso' || theme === 'warm-sunset' || theme === 'dark' ? (
            <>
              <Sun className="w-3.5 h-3.5 text-amber-500" />
              <span>Warm Sand Mode</span>
            </>
          ) : (
            <>
              <Moon className="w-3.5 h-3.5 text-amber-500" />
              <span>Warm Espresso Mode</span>
            </>
          )}
        </motion.button>
      </div>

      {/* Main Form Centerpiece */}
      <div className="max-w-md w-full mx-auto my-6">
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 md:p-8 shadow-2xl transition-all">
          {/* Header */}
          <div className="text-center mb-6">
            <div className="inline-flex items-center justify-center w-12 h-12 rounded-2xl bg-indigo-600/10 dark:bg-indigo-600/20 text-indigo-600 dark:text-indigo-400 mb-3 border border-indigo-500/20 shadow-sm">
              <Bot className="w-6 h-6" />
            </div>
            <h1 className="text-xl font-bold tracking-tight text-slate-900 dark:text-white">
              {isSignUp ? 'Create Your Account' : 'Sign In to Your Account'}
            </h1>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              {isSignUp
                ? 'Follow email and password rules below to initialize your studio'
                : 'Enter your registered Gmail or email credentials'}
            </p>
          </div>

          {/* Validation Alert Notification */}
          <AnimatePresence>
            {errorMessage && (
              <motion.div
                initial={{ opacity: 0, y: -8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -8 }}
                className="mb-4 p-3 rounded-2xl bg-red-50 dark:bg-red-950/60 border border-red-200 dark:border-red-900/60 text-xs text-red-600 dark:text-red-300 flex items-start gap-2 shadow-xs"
              >
                <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                <div className="flex-1">
                  <p className="font-semibold">Rule Requirement Notice</p>
                  <p className="text-[11px] mt-0.5">{errorMessage}</p>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          <form onSubmit={handleSubmit} className="space-y-4 text-xs">
            {/* User Name (only for Sign Up) */}
            {isSignUp && (
              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-medium mb-1">
                  Your Name
                </label>
                <div className="relative">
                  <User className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                  <input
                    type="text"
                    required
                    value={userName}
                    onChange={(e) => setUserName(e.target.value)}
                    placeholder="Enter your name"
                    className="w-full pl-9 pr-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500"
                  />
                </div>
              </div>
            )}

            {/* Email / Gmail Field with Rules */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="block text-slate-700 dark:text-slate-300 font-medium">
                  Gmail / Email Address
                </label>
                {emailTrimmed && (
                  <span
                    className={`text-[10px] font-semibold flex items-center gap-1 ${
                      isEmailValid ? 'text-emerald-600 dark:text-emerald-400' : 'text-amber-500'
                    }`}
                  >
                    {isEmailValid ? (
                      <>
                        <CheckCircle2 className="w-3 h-3" />
                        <span>Valid format</span>
                      </>
                    ) : (
                      <span>Format: name@domain.com</span>
                    )}
                  </span>
                )}
              </div>

              <div className="relative">
                <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => {
                    setEmail(e.target.value);
                    if (errorMessage) setErrorMessage(null);
                  }}
                  placeholder="e.g. praveen@gmail.com"
                  className={`w-full pl-9 pr-24 py-2 bg-slate-50 dark:bg-slate-950 border rounded-xl text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none transition-colors ${
                    hasAttemptedSubmit && !isEmailValid
                      ? 'border-red-500 ring-1 ring-red-500/30'
                      : isEmailValid
                      ? 'border-emerald-500/80 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500'
                      : 'border-slate-200 dark:border-slate-800 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500'
                  }`}
                />

                {/* Autocomplete "+ @gmail.com" button */}
                {!emailTrimmed.includes('@') && emailTrimmed.length > 0 && (
                  <button
                    type="button"
                    onClick={handleAppendGmail}
                    className="absolute right-2 top-1.5 px-2 py-0.5 text-[10px] font-bold rounded-lg bg-indigo-50 dark:bg-indigo-950/80 text-indigo-600 dark:text-indigo-400 border border-indigo-200 dark:border-indigo-800 hover:bg-indigo-100 transition-colors cursor-pointer"
                    title="Append @gmail.com"
                  >
                    + @gmail.com
                  </button>
                )}
              </div>

              {/* Gmail / Email Rules Guideline Box */}
              <div className="mt-1.5 p-2 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200/80 dark:border-slate-800/80 space-y-1 text-[11px]">
                <div className="flex items-center gap-1.5">
                  <div
                    className={`w-3.5 h-3.5 rounded-full flex items-center justify-center shrink-0 ${
                      emailHasAt
                        ? 'bg-emerald-500 text-white'
                        : 'bg-slate-200 dark:bg-slate-800 text-slate-400'
                    }`}
                  >
                    <Check className="w-2.5 h-2.5 stroke-[3]" />
                  </div>
                  <span
                    className={
                      emailHasAt
                        ? 'text-slate-800 dark:text-slate-200 font-medium'
                        : 'text-slate-500'
                    }
                  >
                    Contains &ldquo;@&rdquo; symbol
                  </span>
                </div>

                <div className="flex items-center gap-1.5">
                  <div
                    className={`w-3.5 h-3.5 rounded-full flex items-center justify-center shrink-0 ${
                      isEmailValid
                        ? 'bg-emerald-500 text-white'
                        : 'bg-slate-200 dark:bg-slate-800 text-slate-400'
                    }`}
                  >
                    <Check className="w-2.5 h-2.5 stroke-[3]" />
                  </div>
                  <span
                    className={
                      isEmailValid
                        ? 'text-slate-800 dark:text-slate-200 font-medium'
                        : 'text-slate-500'
                    }
                  >
                    Valid domain and extension (e.g. gmail.com, company.com)
                  </span>
                </div>
              </div>
            </div>

            {/* Password Field with Rules & Strength Meter */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="block text-slate-700 dark:text-slate-300 font-medium">
                  Password
                </label>
                {password && (
                  <span className="text-[10px] font-bold text-slate-500 dark:text-slate-400">
                    Strength: <span className="text-indigo-600 dark:text-indigo-400">{strength.text}</span>
                  </span>
                )}
              </div>

              <div className="relative">
                <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  value={password}
                  onChange={(e) => {
                    setPassword(e.target.value);
                    if (errorMessage) setErrorMessage(null);
                  }}
                  placeholder="Enter strong password"
                  className={`w-full pl-9 pr-10 py-2 bg-slate-50 dark:bg-slate-950 border rounded-xl text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none transition-colors ${
                    hasAttemptedSubmit && !isPasswordValid
                      ? 'border-red-500 ring-1 ring-red-500/30'
                      : isPasswordValid
                      ? 'border-emerald-500/80 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500'
                      : 'border-slate-200 dark:border-slate-800 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500'
                  }`}
                />

                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-2.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 transition-colors cursor-pointer"
                  title={showPassword ? 'Hide password' : 'Show password'}
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>

              {/* Password Strength Bar */}
              {password.length > 0 && (
                <div className="mt-1.5 h-1.5 w-full bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                  <div
                    className={`h-full ${strength.color} transition-all duration-300 rounded-full`}
                    style={{ width: strength.width }}
                  />
                </div>
              )}

              {/* Password Rules Checklist */}
              <div className="mt-2 p-2.5 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200/80 dark:border-slate-800/80 space-y-1.5 text-[11px]">
                <p className="font-semibold text-slate-700 dark:text-slate-300 text-[10px] uppercase tracking-wider mb-1 flex items-center justify-between">
                  <span>Password Rules:</span>
                  <span>{passwordRulesCount} / 5 passed</span>
                </p>

                {/* Rule 1: Min length 8 */}
                <div className="flex items-center gap-1.5">
                  <div
                    className={`w-3.5 h-3.5 rounded-full flex items-center justify-center shrink-0 ${
                      passMinLength
                        ? 'bg-emerald-500 text-white'
                        : 'bg-slate-200 dark:bg-slate-800 text-slate-400'
                    }`}
                  >
                    <Check className="w-2.5 h-2.5 stroke-[3]" />
                  </div>
                  <span
                    className={
                      passMinLength
                        ? 'text-slate-800 dark:text-slate-200 font-medium'
                        : 'text-slate-500'
                    }
                  >
                    At least 8 characters long
                  </span>
                </div>

                {/* Rule 2: Uppercase */}
                <div className="flex items-center gap-1.5">
                  <div
                    className={`w-3.5 h-3.5 rounded-full flex items-center justify-center shrink-0 ${
                      passHasUpper
                        ? 'bg-emerald-500 text-white'
                        : 'bg-slate-200 dark:bg-slate-800 text-slate-400'
                    }`}
                  >
                    <Check className="w-2.5 h-2.5 stroke-[3]" />
                  </div>
                  <span
                    className={
                      passHasUpper
                        ? 'text-slate-800 dark:text-slate-200 font-medium'
                        : 'text-slate-500'
                    }
                  >
                    At least one uppercase letter (A–Z)
                  </span>
                </div>

                {/* Rule 3: Lowercase */}
                <div className="flex items-center gap-1.5">
                  <div
                    className={`w-3.5 h-3.5 rounded-full flex items-center justify-center shrink-0 ${
                      passHasLower
                        ? 'bg-emerald-500 text-white'
                        : 'bg-slate-200 dark:bg-slate-800 text-slate-400'
                    }`}
                  >
                    <Check className="w-2.5 h-2.5 stroke-[3]" />
                  </div>
                  <span
                    className={
                      passHasLower
                        ? 'text-slate-800 dark:text-slate-200 font-medium'
                        : 'text-slate-500'
                    }
                  >
                    At least one lowercase letter (a–z)
                  </span>
                </div>

                {/* Rule 4: Number */}
                <div className="flex items-center gap-1.5">
                  <div
                    className={`w-3.5 h-3.5 rounded-full flex items-center justify-center shrink-0 ${
                      passHasNumber
                        ? 'bg-emerald-500 text-white'
                        : 'bg-slate-200 dark:bg-slate-800 text-slate-400'
                    }`}
                  >
                    <Check className="w-2.5 h-2.5 stroke-[3]" />
                  </div>
                  <span
                    className={
                      passHasNumber
                        ? 'text-slate-800 dark:text-slate-200 font-medium'
                        : 'text-slate-500'
                    }
                  >
                    At least one numeric digit (0–9)
                  </span>
                </div>

                {/* Rule 5: Special character */}
                <div className="flex items-center gap-1.5">
                  <div
                    className={`w-3.5 h-3.5 rounded-full flex items-center justify-center shrink-0 ${
                      passHasSpecial
                        ? 'bg-emerald-500 text-white'
                        : 'bg-slate-200 dark:bg-slate-800 text-slate-400'
                    }`}
                  >
                    <Check className="w-2.5 h-2.5 stroke-[3]" />
                  </div>
                  <span
                    className={
                      passHasSpecial
                        ? 'text-slate-800 dark:text-slate-200 font-medium'
                        : 'text-slate-500'
                    }
                  >
                    At least one symbol (!, @, #, $, %, etc.)
                  </span>
                </div>
              </div>
            </div>

            {/* Custom AI Name Section (Sign Up) */}
            {isSignUp && (
              <div className="p-3.5 rounded-xl bg-indigo-50/70 dark:bg-indigo-950/40 border border-indigo-100 dark:border-indigo-900/60 space-y-2 mt-2">
                <div className="flex items-center justify-between">
                  <label className="block text-indigo-950 dark:text-indigo-200 font-semibold flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-indigo-500" />
                    <span>Customize Your AI Assistant Name</span>
                  </label>
                </div>

                <input
                  type="text"
                  value={customAiName}
                  onChange={(e) => setCustomAiName(e.target.value)}
                  placeholder="e.g. Jarvis, Athena, Aura..."
                  className="w-full px-3 py-2 bg-white dark:bg-slate-900 border border-indigo-200 dark:border-indigo-800/80 rounded-lg text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:border-indigo-500 font-medium"
                />

                {/* Suggestions */}
                <div className="flex flex-wrap gap-1.5 pt-1">
                  <span className="text-[10px] text-slate-500 dark:text-slate-400 py-0.5">
                    Quick picks:
                  </span>
                  {AI_NAME_SUGGESTIONS.map((sug) => (
                    <button
                      key={sug}
                      type="button"
                      onClick={() => setCustomAiName(sug)}
                      className={`px-2 py-0.5 text-[10px] rounded-md transition-all font-medium cursor-pointer ${
                        customAiName.toLowerCase() === sug.toLowerCase()
                          ? 'bg-indigo-600 text-white shadow-xs'
                          : 'bg-white/80 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-white dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700'
                      }`}
                    >
                      {sug}
                    </button>
                  ))}
                </div>

                {/* Live Preview Card */}
                <div className="pt-1 text-[11px] text-indigo-700 dark:text-indigo-300 flex items-center gap-1.5">
                  <Bot className="w-3.5 h-3.5 shrink-0" />
                  <span>
                    &ldquo;Hello {userName || 'Explorer'}, I am <strong>{customAiName || 'Nova'}</strong>!&rdquo;
                  </span>
                </div>
              </div>
            )}

            {/* Submit Button with Framer Motion tactile click */}
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.96 }}
              type="submit"
              className="w-full py-2.5 px-4 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-xl transition-all shadow-md shadow-indigo-600/20 flex items-center justify-center gap-2 mt-4 cursor-pointer"
            >
              <span>{isSignUp ? `Verify Rules & Launch ${customAiName || 'AI'}` : 'Verify Rules & Sign In'}</span>
              <ArrowRight className="w-4 h-4" />
            </motion.button>

            {/* Quick Demo Sign In with sample compliant credentials */}
            <motion.button
              whileHover={{ scale: 1.01 }}
              whileTap={{ scale: 0.98 }}
              type="button"
              onClick={handleQuickDemo}
              className="w-full py-2 px-4 text-xs font-medium text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700/80 rounded-xl transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
              <span>One-Click Guest Sign In (alex.rivers@gmail.com)</span>
            </motion.button>
          </form>

          {/* Toggle between Sign Up and Sign In */}
          <div className="text-center mt-5 pt-4 border-t border-slate-100 dark:border-slate-800 text-xs text-slate-500">
            {isSignUp ? (
              <p>
                Already have an account?{' '}
                <button
                  type="button"
                  onClick={() => {
                    setIsSignUp(false);
                    setErrorMessage(null);
                  }}
                  className="text-indigo-600 dark:text-indigo-400 font-semibold hover:underline cursor-pointer"
                >
                  Sign In
                </button>
              </p>
            ) : (
              <p>
                Need a new account?{' '}
                <button
                  type="button"
                  onClick={() => {
                    setIsSignUp(true);
                    setErrorMessage(null);
                  }}
                  className="text-indigo-600 dark:text-indigo-400 font-semibold hover:underline cursor-pointer"
                >
                  Create one now with rules
                </button>
              </p>
            )}
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="text-center text-[11px] text-slate-400 max-w-sm mx-auto">
        Secure AI Studio Authentication · Password & Gmail validation enforced
      </div>
    </div>
  );
};
