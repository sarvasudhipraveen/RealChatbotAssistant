import React, { useState } from 'react';
import { X, Calendar as CalendarIcon, ChevronLeft, ChevronRight, Plus, Check, Clock } from 'lucide-react';

interface CalendarEvent {
  id: string;
  title: string;
  time: string;
  date: string;
  category: 'work' | 'personal' | 'ai-task';
}

interface CalendarModalProps {
  onClose: () => void;
  onAskAiToPlan?: (dateStr: string) => void;
}

export const CalendarModal: React.FC<CalendarModalProps> = ({ onClose, onAskAiToPlan }) => {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedDay, setSelectedDay] = useState<number>(new Date().getDate());
  const [newEventTitle, setNewEventTitle] = useState('');
  const [newEventTime, setNewEventTime] = useState('10:00 AM');
  const [showAddForm, setShowAddForm] = useState(false);

  const [events, setEvents] = useState<CalendarEvent[]>([
    {
      id: '1',
      title: 'Review Project Roadmaps',
      time: '09:30 AM',
      date: new Date().toISOString().split('T')[0],
      category: 'work',
    },
    {
      id: '2',
      title: 'AI Assisted Content Brainstorming',
      time: '02:00 PM',
      date: new Date().toISOString().split('T')[0],
      category: 'ai-task',
    },
  ]);

  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();

  const monthNames = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December',
  ];

  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const firstDayIndex = new Date(year, month, 1).getDay();

  const handlePrevMonth = () => {
    setCurrentDate(new Date(year, month - 1, 1));
  };

  const handleNextMonth = () => {
    setCurrentDate(new Date(year, month + 1, 1));
  };

  const selectedDateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(selectedDay).padStart(2, '0')}`;
  const dayEvents = events.filter((e) => e.date === selectedDateStr);

  const handleAddEvent = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newEventTitle.trim()) return;

    const newEv: CalendarEvent = {
      id: 'ev-' + Date.now(),
      title: newEventTitle.trim(),
      time: newEventTime,
      date: selectedDateStr,
      category: 'work',
    };

    setEvents((prev) => [...prev, newEv]);
    setNewEventTitle('');
    setShowAddForm(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-2xl overflow-hidden shadow-2xl flex flex-col text-slate-900 dark:text-slate-100 transition-colors">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-indigo-600/10 dark:bg-indigo-600/20 text-indigo-600 dark:text-indigo-400 flex items-center justify-center">
              <CalendarIcon className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-semibold text-slate-900 dark:text-white">Calendar & Daily Planner</h3>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">Manage daily schedule and plan with Nova AI</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-700 dark:hover:text-white p-1 rounded-lg hover:bg-slate-200 dark:hover:bg-slate-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Calendar & Agenda layout */}
        <div className="p-5 grid grid-cols-1 md:grid-cols-2 gap-5">
          {/* Left: Monthly Calendar Grid */}
          <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800">
            {/* Month Navigator */}
            <div className="flex items-center justify-between mb-3 text-xs">
              <span className="font-semibold text-slate-800 dark:text-slate-200">
                {monthNames[month]} {year}
              </span>
              <div className="flex items-center gap-1">
                <button
                  onClick={handlePrevMonth}
                  className="p-1 rounded hover:bg-slate-200 dark:hover:bg-slate-800 text-slate-500"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>
                <button
                  onClick={handleNextMonth}
                  className="p-1 rounded hover:bg-slate-200 dark:hover:bg-slate-800 text-slate-500"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Days of Week Header */}
            <div className="grid grid-cols-7 gap-1 text-center text-[10px] font-semibold text-slate-400 mb-1">
              <span>Su</span><span>Mo</span><span>Tu</span><span>We</span><span>Th</span><span>Fr</span><span>Sa</span>
            </div>

            {/* Calendar Days */}
            <div className="grid grid-cols-7 gap-1 text-xs">
              {Array.from({ length: firstDayIndex }).map((_, i) => (
                <div key={`empty-${i}`} className="h-7" />
              ))}

              {Array.from({ length: daysInMonth }).map((_, i) => {
                const dayNum = i + 1;
                const isSelected = selectedDay === dayNum;
                const isToday =
                  dayNum === new Date().getDate() &&
                  month === new Date().getMonth() &&
                  year === new Date().getFullYear();

                const dStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(dayNum).padStart(2, '0')}`;
                const hasEvent = events.some((e) => e.date === dStr);

                return (
                  <button
                    key={dayNum}
                    onClick={() => setSelectedDay(dayNum)}
                    className={`h-7 rounded-lg flex items-center justify-center relative transition-all ${
                      isSelected
                        ? 'bg-indigo-600 text-white font-bold shadow-sm'
                        : isToday
                        ? 'bg-indigo-100 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400 font-semibold'
                        : 'hover:bg-slate-200 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300'
                    }`}
                  >
                    <span>{dayNum}</span>
                    {hasEvent && !isSelected && (
                      <span className="w-1 h-1 rounded-full bg-indigo-500 absolute bottom-1" />
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Right: Selected Day Events & Planning */}
          <div className="flex flex-col h-full justify-between space-y-3">
            <div>
              <div className="flex items-center justify-between mb-2">
                <h4 className="text-xs font-semibold text-slate-800 dark:text-slate-200">
                  Schedule for {monthNames[month]} {selectedDay}
                </h4>
                <button
                  onClick={() => setShowAddForm(!showAddForm)}
                  className="flex items-center gap-1 text-[11px] text-indigo-600 dark:text-indigo-400 hover:underline font-medium"
                >
                  <Plus className="w-3 h-3" />
                  <span>{showAddForm ? 'Cancel' : 'Add Event'}</span>
                </button>
              </div>

              {/* Add event form */}
              {showAddForm && (
                <form onSubmit={handleAddEvent} className="p-2.5 rounded-lg bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 space-y-2 mb-3 text-xs">
                  <input
                    type="text"
                    value={newEventTitle}
                    onChange={(e) => setNewEventTitle(e.target.value)}
                    placeholder="Event title or reminder..."
                    className="w-full px-2.5 py-1.5 rounded bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white text-xs focus:outline-none"
                    autoFocus
                  />
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={newEventTime}
                      onChange={(e) => setNewEventTime(e.target.value)}
                      placeholder="e.g. 10:00 AM"
                      className="w-28 px-2.5 py-1 rounded bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white text-xs focus:outline-none"
                    />
                    <button
                      type="submit"
                      className="px-3 py-1 bg-indigo-600 hover:bg-indigo-500 text-white rounded text-xs font-medium"
                    >
                      Save
                    </button>
                  </div>
                </form>
              )}

              {/* Events List */}
              <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
                {dayEvents.length === 0 ? (
                  <div className="text-center py-6 text-xs text-slate-400">
                    No scheduled events for this day.
                  </div>
                ) : (
                  dayEvents.map((ev) => (
                    <div
                      key={ev.id}
                      className="flex items-center justify-between p-2.5 rounded-lg bg-slate-100 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60 text-xs"
                    >
                      <div className="flex items-center gap-2">
                        <Clock className="w-3.5 h-3.5 text-indigo-500 shrink-0" />
                        <div>
                          <div className="font-medium text-slate-900 dark:text-white">{ev.title}</div>
                          <div className="text-[10px] text-slate-500">{ev.time}</div>
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>

            {/* AI Day Planning Action */}
            {onAskAiToPlan && (
              <div className="pt-2 border-t border-slate-200 dark:border-slate-800">
                <button
                  onClick={() => {
                    onAskAiToPlan(`${monthNames[month]} ${selectedDay}, ${year}`);
                    onClose();
                  }}
                  className="w-full py-2 px-3 text-xs font-medium rounded-lg bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 hover:bg-indigo-100 dark:hover:bg-indigo-900/50 border border-indigo-200 dark:border-indigo-800/60 transition-colors flex items-center justify-center gap-1.5"
                >
                  <CalendarIcon className="w-3.5 h-3.5" />
                  <span>Ask Nova to plan schedule for this day</span>
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="px-5 py-3 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-lg transition-colors"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
