import React, { useRef, useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import {
  Send,
  Square,
  Sparkles,
  ChevronDown,
  Paperclip,
  Image as ImageIcon,
  Mic,
  MicOff,
  X,
  FileText,
  Loader2,
  Globe,
  Radio,
} from 'lucide-react';
import { Persona, FileAttachment } from '../../types/chat';
import { createSpeechRecognition } from '../../utils/voiceAssistant';

interface ChatInputProps {
  onSend: (text: string, attachments?: FileAttachment[]) => void;
  onStop: () => void;
  isStreaming: boolean;
  selectedPersona: Persona;
  personas: Persona[];
  onSelectPersona: (persona: Persona) => void;
  suggestedPrompts: string[];
  activeModel?: string;
  onOpenSettings?: () => void;
  useGoogleSearch?: boolean;
  onToggleGoogleSearch?: () => void;
  onOpenLiveVoice?: () => void;
}

export const ChatInput: React.FC<ChatInputProps> = ({
  onSend,
  onStop,
  isStreaming,
  selectedPersona,
  personas,
  onSelectPersona,
  suggestedPrompts,
  activeModel = 'gemini-3.5-flash',
  onOpenSettings,
  useGoogleSearch = false,
  onToggleGoogleSearch,
  onOpenLiveVoice,
}) => {
  const [input, setInput] = useState('');
  const [attachments, setAttachments] = useState<FileAttachment[]>([]);
  const [isUploading, setIsUploading] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [showPersonaMenu, setShowPersonaMenu] = useState(false);

  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const recognitionRef = useRef<any>(null);

  // Auto-resize textarea height
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 180)}px`;
    }
  }, [input]);

  // Handle Voice Assistant Microphone
  const toggleListening = () => {
    if (isListening) {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
      setIsListening(false);
      return;
    }

    const recognition = createSpeechRecognition();
    if (!recognition) {
      alert('Speech recognition is not supported in this browser. Please use Chrome, Edge, or Safari.');
      return;
    }

    recognitionRef.current = recognition;
    setIsListening(true);

    recognition.onresult = (event: any) => {
      let transcript = '';
      for (let i = event.resultIndex; i < event.results.length; ++i) {
        transcript += event.results[i][0].transcript;
      }
      if (transcript) {
        setInput((prev) => (prev ? `${prev.trim()} ${transcript}` : transcript));
      }
    };

    recognition.onerror = (event: any) => {
      console.warn('Speech recognition error:', event.error);
      setIsListening(false);
    };

    recognition.onend = () => {
      setIsListening(false);
    };

    try {
      recognition.start();
    } catch (e) {
      console.error(e);
      setIsListening(false);
    }
  };

  // Handle File & Photo selection
  const handleFilesSelected = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    setIsUploading(true);
    const newAttachments: FileAttachment[] = [];

    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      const isImage = file.type.startsWith('image/');

      try {
        const dataUrl = await new Promise<string>((resolve, reject) => {
          const reader = new FileReader();
          reader.onload = () => resolve(reader.result as string);
          reader.onerror = reject;
          reader.readAsDataURL(file);
        });

        let textContent: string | undefined;
        if (!isImage && (file.type.includes('text') || file.name.match(/\.(txt|md|csv|json|py|js|ts|html|css)$/i))) {
          textContent = await new Promise<string>((resolve) => {
            const textReader = new FileReader();
            textReader.onload = () => resolve((textReader.result as string) || '');
            textReader.onerror = () => resolve('');
            textReader.readAsText(file);
          });
        }

        newAttachments.push({
          id: 'att-' + Date.now() + '-' + i,
          name: file.name,
          type: file.type || 'application/octet-stream',
          size: file.size,
          dataUrl,
          isImage,
          textContent,
        });
      } catch (err) {
        console.error('Error reading file:', err);
      }
    }

    setAttachments((prev) => [...prev, ...newAttachments]);
    setIsUploading(false);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const removeAttachment = (id: string) => {
    setAttachments((prev) => prev.filter((a) => a.id !== id));
  };

  const handleSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if ((!input.trim() && attachments.length === 0) || isStreaming) return;

    onSend(input, attachments.length > 0 ? attachments : undefined);
    setInput('');
    setAttachments([]);
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };

  return (
    <div className="border-t border-slate-200 dark:border-slate-800/80 bg-white/95 dark:bg-slate-950/95 backdrop-blur-md p-3 md:p-4 transition-colors">
      <div className="max-w-3xl mx-auto space-y-2.5">
        {/* Suggested Prompts */}
        {suggestedPrompts.length > 0 && attachments.length === 0 && (
          <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs no-scrollbar">
            {suggestedPrompts.map((prompt, idx) => (
              <button
                key={idx}
                onClick={() => onSend(prompt)}
                disabled={isStreaming}
                className="shrink-0 px-3 py-1.5 text-slate-600 dark:text-slate-300 bg-slate-100 dark:bg-slate-900/90 hover:bg-slate-200 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-800 rounded-full hover:border-slate-300 dark:hover:border-slate-700 transition-all text-left truncate max-w-sm"
              >
                {prompt}
              </button>
            ))}
          </div>
        )}

        {/* Input Card */}
        <div className="relative rounded-2xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700/70 focus-within:border-indigo-500 focus-within:ring-1 focus-within:ring-indigo-500 transition-all shadow-md dark:shadow-xl dark:shadow-black/30">
          {/* Persona selector & Model badge */}
          <div className="flex items-center justify-between px-3.5 pt-2.5 pb-1 border-b border-slate-200/80 dark:border-slate-800/60 text-xs">
            <div className="relative">
              <button
                type="button"
                onClick={() => setShowPersonaMenu(!showPersonaMenu)}
                className="flex items-center gap-1.5 text-slate-700 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white transition-colors py-1 px-2 rounded-md hover:bg-slate-200/70 dark:hover:bg-slate-800 font-medium"
              >
                <Sparkles className="w-3.5 h-3.5 text-indigo-500 dark:text-indigo-400" />
                <span>Mode: {selectedPersona.name}</span>
                <ChevronDown className="w-3 h-3 text-slate-400" />
              </button>

              {showPersonaMenu && (
                <div className="absolute bottom-full left-0 mb-2 w-72 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl shadow-2xl overflow-hidden z-30">
                  <div className="p-2 border-b border-slate-100 dark:border-slate-800 text-[11px] font-semibold text-slate-500 dark:text-slate-400">
                    Choose Assistant Mode
                  </div>
                  <div className="max-h-64 overflow-y-auto p-1 space-y-1">
                    {personas.map((p) => (
                      <button
                        key={p.id}
                        type="button"
                        onClick={() => {
                          onSelectPersona(p);
                          setShowPersonaMenu(false);
                        }}
                        className={`w-full text-left p-2.5 rounded-lg text-xs transition-colors flex flex-col ${
                          p.id === selectedPersona.id
                            ? 'bg-indigo-50 dark:bg-indigo-600/20 text-indigo-600 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-500/30'
                            : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white'
                        }`}
                      >
                        <span className="font-semibold">{p.name}</span>
                        <span className="text-[11px] text-slate-500 dark:text-slate-400">{p.roleTitle}</span>
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>

            <div className="flex items-center gap-1.5 md:gap-2">
              {/* Google Search Grounding Toggle */}
              {onToggleGoogleSearch && (
                <motion.button
                  whileHover={{ scale: 1.04 }}
                  whileTap={{ scale: 0.94 }}
                  type="button"
                  onClick={onToggleGoogleSearch}
                  className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-medium transition-all cursor-pointer ${
                    useGoogleSearch
                      ? 'bg-blue-600 text-white shadow-sm shadow-blue-500/20'
                      : 'text-slate-600 dark:text-slate-400 hover:text-blue-600 dark:hover:text-blue-400 bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700'
                  }`}
                  title={
                    useGoogleSearch
                      ? 'Google Search Grounding is ON (gemini-3.5-flash with googleSearch tool)'
                      : 'Enable Google Search Grounding for live, up-to-date web information'
                  }
                >
                  <Globe className={`w-3.5 h-3.5 ${useGoogleSearch ? 'animate-spin' : ''}`} />
                  <span className="hidden sm:inline">
                    {useGoogleSearch ? 'Search Grounding ON' : 'Google Search'}
                  </span>
                </motion.button>
              )}

              {/* Gemini 3.8 Live API Voice Call Button */}
              {onOpenLiveVoice && (
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.92 }}
                  type="button"
                  onClick={onOpenLiveVoice}
                  className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-semibold bg-gradient-to-r from-indigo-600 to-violet-600 text-white hover:from-indigo-500 hover:to-violet-500 shadow-sm shadow-indigo-600/20 cursor-pointer"
                  title="Start real-time voice conversation with Gemini 3.8 Live"
                >
                  <Radio className="w-3.5 h-3.5 animate-pulse" />
                  <span className="hidden sm:inline">Live Voice</span>
                </motion.button>
              )}

              {/* Model Selector Badge */}
              <motion.button
                whileHover={{ scale: 1.04 }}
                whileTap={{ scale: 0.95 }}
                type="button"
                onClick={onOpenSettings}
                className="text-[11px] text-indigo-600 dark:text-indigo-400 hover:text-indigo-700 dark:hover:text-indigo-300 font-mono px-2 py-0.5 rounded bg-indigo-50 dark:bg-indigo-950/40 border border-indigo-200 dark:border-indigo-500/30 transition-colors cursor-pointer"
                title="Change model or settings"
              >
                {activeModel.replace('gemini-', 'Gemini ').replace('openai/', '').replace('anthropic/', '').replace('groq/', '')}
              </motion.button>
            </div>
          </div>

          {/* Attached Files & Photos Preview Bar */}
          {attachments.length > 0 && (
            <div className="flex items-center gap-2 px-3 pt-2.5 pb-1 overflow-x-auto">
              {attachments.map((att) => (
                <div
                  key={att.id}
                  className="relative group flex items-center gap-2 p-1.5 pr-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl shadow-sm text-xs shrink-0"
                >
                  {att.isImage ? (
                    <img
                      src={att.dataUrl}
                      alt={att.name}
                      className="w-10 h-10 rounded-lg object-cover border border-slate-200 dark:border-slate-700"
                    />
                  ) : (
                    <div className="w-10 h-10 rounded-lg bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center">
                      <FileText className="w-5 h-5" />
                    </div>
                  )}

                  <div className="max-w-[120px]">
                    <p className="text-[11px] font-medium text-slate-800 dark:text-slate-200 truncate">
                      {att.name}
                    </p>
                    <p className="text-[9px] text-slate-400">
                      {Math.round(att.size / 1024)} KB
                    </p>
                  </div>

                  <button
                    type="button"
                    onClick={() => removeAttachment(att.id)}
                    className="p-1 text-slate-400 hover:text-red-500 rounded-full hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors"
                    title="Remove attachment"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
            </div>
          )}

          {/* Listening Audio Waves Indicator */}
          {isListening && (
            <div className="flex items-center gap-2 px-4 py-1.5 bg-indigo-50/80 dark:bg-indigo-950/50 text-indigo-600 dark:text-indigo-400 text-xs font-medium border-t border-indigo-100 dark:border-indigo-900/50 animate-pulse">
              <span className="w-2 h-2 rounded-full bg-red-500 animate-ping" />
              <span>Voice Assistant is listening... Speak your question</span>
            </div>
          )}

          {/* Textarea + Action Tools */}
          <div className="flex items-end gap-2 p-3">
            {/* Hidden file upload input */}
            <input
              ref={fileInputRef}
              type="file"
              multiple
              accept="image/*,.pdf,.txt,.md,.json,.csv,.js,.ts,.py,.html"
              className="hidden"
              onChange={handleFilesSelected}
            />

            {/* Upload Button */}
            <motion.button
              whileHover={{ scale: 1.08 }}
              whileTap={{ scale: 0.9 }}
              type="button"
              onClick={() => fileInputRef.current?.click()}
              disabled={isUploading || isStreaming}
              className="p-2 text-slate-500 hover:text-indigo-600 dark:text-slate-400 dark:hover:text-indigo-400 rounded-xl hover:bg-slate-200/60 dark:hover:bg-slate-800 transition-colors shrink-0 cursor-pointer disabled:opacity-40"
              title="Upload photo or file"
            >
              {isUploading ? (
                <Loader2 className="w-4 h-4 animate-spin text-indigo-500" />
              ) : (
                <Paperclip className="w-4 h-4" />
              )}
            </motion.button>

            {/* Voice Assistant Microphone Button */}
            <motion.button
              whileHover={{ scale: 1.08 }}
              whileTap={{ scale: 0.9 }}
              type="button"
              onClick={toggleListening}
              disabled={isStreaming}
              className={`p-2 rounded-xl transition-all shrink-0 cursor-pointer ${
                isListening
                  ? 'bg-red-500 text-white shadow-md shadow-red-500/30 animate-pulse'
                  : 'text-slate-500 hover:text-indigo-600 dark:text-slate-400 dark:hover:text-indigo-400 hover:bg-slate-200/60 dark:hover:bg-slate-800'
              }`}
              title={isListening ? 'Stop listening' : 'Speak with Voice Assistant (Microphone)'}
            >
              {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
            </motion.button>

            {/* Input field */}
            <textarea
              ref={textareaRef}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder={
                attachments.length > 0
                  ? 'Ask anything about the attached photo or file...'
                  : `Ask ${selectedPersona.name} anything or speak with the voice assistant...`
              }
              disabled={isStreaming}
              rows={1}
              className="w-full bg-transparent resize-none border-0 text-sm text-slate-900 dark:text-slate-100 placeholder-slate-400 dark:placeholder-slate-500 focus:outline-none focus:ring-0 leading-relaxed max-h-44"
            />

            {/* Submit / Stop button */}
            <div className="shrink-0 flex items-center gap-1.5">
              {isStreaming ? (
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.92 }}
                  type="button"
                  onClick={onStop}
                  className="flex items-center gap-1 px-3 py-2 text-xs font-semibold text-white bg-red-600 hover:bg-red-500 rounded-xl transition-all shadow-sm cursor-pointer"
                  title="Stop generating"
                >
                  <Square className="w-3.5 h-3.5 fill-current" />
                  <span>Stop</span>
                </motion.button>
              ) : (
                <motion.button
                  whileHover={{ scale: 1.08 }}
                  whileTap={{ scale: 0.88 }}
                  type="button"
                  onClick={() => handleSubmit()}
                  disabled={!input.trim() && attachments.length === 0}
                  className="flex items-center justify-center w-8 h-8 rounded-xl bg-indigo-600 text-white hover:bg-indigo-500 disabled:opacity-30 disabled:hover:bg-indigo-600 transition-all shadow-sm shadow-indigo-600/20 cursor-pointer"
                  title="Send message"
                >
                  <Send className="w-4 h-4" />
                </motion.button>
              )}
            </div>
          </div>
        </div>

        {/* Quiet footer tip */}
        <div className="text-center text-[11px] text-slate-400 dark:text-slate-500">
          Upload photos & files · Voice Assistant enabled · Enter to send
        </div>
      </div>
    </div>
  );
};
