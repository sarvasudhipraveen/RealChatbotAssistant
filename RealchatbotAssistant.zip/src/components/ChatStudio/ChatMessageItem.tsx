import React, { useState } from 'react';
import {
  Copy,
  Check,
  RotateCw,
  AlertTriangle,
  Sparkles,
  User,
  Volume2,
  VolumeX,
  FileText,
  Maximize2,
  X,
  Globe,
  ExternalLink,
  Search,
} from 'lucide-react';
import { Message, FileAttachment } from '../../types/chat';
import { MarkdownView } from './MarkdownView';
import { speakText, stopSpeaking } from '../../utils/voiceAssistant';
import { useAuth } from '../../context/AuthContext';

interface ChatMessageItemProps {
  message: Message;
  onRetry?: (message: Message) => void;
}

export const ChatMessageItem: React.FC<ChatMessageItemProps> = ({
  message,
  onRetry,
}) => {
  const { user, aiConfig } = useAuth();
  const [copied, setCopied] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [expandedImage, setExpandedImage] = useState<string | null>(null);

  const isUser = message.role === 'user';
  const isStreaming = message.status === 'streaming';
  const isError = message.status === 'error';

  const handleCopyMessage = () => {
    navigator.clipboard.writeText(message.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleToggleSpeak = () => {
    if (isSpeaking) {
      stopSpeaking();
      setIsSpeaking(false);
    } else {
      speakText(
        message.content,
        {},
        () => setIsSpeaking(true),
        () => setIsSpeaking(false),
        () => setIsSpeaking(false)
      );
    }
  };

  const formattedTime = new Date(message.timestamp).toLocaleTimeString([], {
    hour: '2-digit',
    minute: '2-digit',
  });

  return (
    <>
      <div
        className={`group flex gap-3.5 px-4 md:px-6 py-3 transition-colors ${
          isUser ? 'justify-end' : 'justify-start hover:bg-slate-100/60 dark:hover:bg-slate-900/30'
        }`}
      >
        {!isUser && (
          <div className="w-8 h-8 rounded-xl bg-indigo-600/10 dark:bg-indigo-600/20 border border-indigo-500/20 dark:border-indigo-500/30 flex items-center justify-center shrink-0 text-indigo-600 dark:text-indigo-400 shadow-sm mt-0.5">
            <Sparkles className="w-4 h-4" />
          </div>
        )}

        <div
          className={`flex flex-col max-w-[85%] md:max-w-[75%] ${
            isUser ? 'items-end' : 'items-start'
          }`}
        >
          {/* Author & Timestamp Header */}
          <div className="flex items-center gap-2 mb-1.5 text-xs text-slate-400 dark:text-slate-500">
            <span className="font-medium text-slate-600 dark:text-slate-400">
              {isUser ? (user?.name ? user.name.split(' ')[0] : 'You') : (aiConfig.name || 'Nova AI')}
            </span>
            <span aria-hidden="true">·</span>
            <span className="tabular-nums">{formattedTime}</span>
          </div>

          {/* Attached Photos / Files inside the bubble */}
          {message.attachments && message.attachments.length > 0 && (
            <div className={`mb-2 flex flex-wrap gap-2 ${isUser ? 'justify-end' : 'justify-start'}`}>
              {message.attachments.map((att: FileAttachment) => (
                <div key={att.id}>
                  {att.isImage ? (
                    <div
                      onClick={() => setExpandedImage(att.dataUrl)}
                      className="relative group/img cursor-pointer rounded-xl overflow-hidden border border-slate-200 dark:border-slate-700 shadow-sm max-w-[200px]"
                    >
                      <img
                        src={att.dataUrl}
                        alt={att.name}
                        className="w-full h-32 object-cover transition-transform group-hover/img:scale-105"
                      />
                      <div className="absolute inset-0 bg-black/40 opacity-0 group-hover/img:opacity-100 transition-opacity flex items-center justify-center text-white">
                        <Maximize2 className="w-4 h-4" />
                      </div>
                    </div>
                  ) : (
                    <div className="flex items-center gap-2 px-3 py-2 bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs max-w-xs shadow-sm">
                      <FileText className="w-4 h-4 text-indigo-500 shrink-0" />
                      <div className="truncate">
                        <p className="font-medium text-slate-800 dark:text-slate-200 truncate">{att.name}</p>
                        <p className="text-[10px] text-slate-400">{Math.round(att.size / 1024)} KB</p>
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}

          {/* Message Bubble */}
          <div
            className={`relative rounded-2xl px-4 py-3.5 text-sm ${
              isUser
                ? 'bg-indigo-600 text-white rounded-tr-sm shadow-md shadow-indigo-900/20'
                : isError
                ? 'bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-800/80 text-red-700 dark:text-red-200 rounded-tl-sm'
                : 'bg-white dark:bg-slate-900/90 border border-slate-200/90 dark:border-slate-800/90 text-slate-800 dark:text-slate-100 rounded-tl-sm shadow-sm'
            }`}
          >
            {isError ? (
              <div className="flex items-start gap-2 text-red-600 dark:text-red-300">
                <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5 text-red-500 dark:text-red-400" />
                <div>
                  <p className="font-semibold text-xs text-red-600 dark:text-red-300 mb-1">Message could not be sent</p>
                  <p className="text-xs leading-relaxed">{message.error || message.content}</p>
                  {onRetry && (
                    <button
                      onClick={() => onRetry(message)}
                      className="mt-2.5 inline-flex items-center gap-1.5 px-3 py-1 text-xs font-medium text-red-700 dark:text-red-200 bg-red-100 dark:bg-red-900/50 hover:bg-red-200 dark:hover:bg-red-900 rounded-md transition-colors"
                    >
                      <RotateCw className="w-3 h-3" /> Try Again
                    </button>
                  )}
                </div>
              </div>
            ) : isUser ? (
              <p className="whitespace-pre-wrap leading-relaxed">{message.content}</p>
            ) : (
              <div className="space-y-1">
                <MarkdownView content={message.content} />
                {isStreaming && (
                  <span className="inline-block w-2 h-4 ml-1 bg-indigo-500 rounded-sm animate-pulse align-middle" />
                )}

                {/* Google Search Grounding Data Section */}
                {message.groundingMetadata && (
                  <div className="mt-3 pt-2.5 border-t border-slate-200/70 dark:border-slate-800 text-xs">
                    <div className="flex items-center gap-1.5 font-semibold text-slate-700 dark:text-slate-300 mb-2">
                      <Globe className="w-3.5 h-3.5 text-blue-500" />
                      <span>Google Search Grounding Data</span>
                    </div>

                    {/* Search queries used */}
                    {message.groundingMetadata.webSearchQueries &&
                      message.groundingMetadata.webSearchQueries.length > 0 && (
                        <div className="flex flex-wrap items-center gap-1 mb-2">
                          <span className="text-[10px] text-slate-400">Searched:</span>
                          {message.groundingMetadata.webSearchQueries.map((query, idx) => (
                            <span
                              key={idx}
                              className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] bg-blue-50 dark:bg-blue-950/40 text-blue-600 dark:text-blue-400 border border-blue-200 dark:border-blue-900/60"
                            >
                              <Search className="w-2.5 h-2.5" />
                              <span>{query}</span>
                            </span>
                          ))}
                        </div>
                      )}

                    {/* Source citation links */}
                    {message.groundingMetadata.searchChunks &&
                      message.groundingMetadata.searchChunks.length > 0 && (
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
                          {message.groundingMetadata.searchChunks
                            .filter((chunk) => chunk.web?.uri)
                            .slice(0, 6)
                            .map((chunk, idx) => (
                              <a
                                key={idx}
                                href={chunk.web!.uri}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="flex items-center justify-between p-1.5 rounded-lg bg-slate-50 dark:bg-slate-900/80 hover:bg-slate-100 dark:hover:bg-slate-800/80 border border-slate-200 dark:border-slate-800 transition-colors group/link text-left"
                              >
                                <span className="truncate text-[11px] font-medium text-slate-700 dark:text-slate-300 group-hover/link:text-blue-600 dark:group-hover/link:text-blue-400">
                                  {chunk.web!.title || chunk.web!.uri}
                                </span>
                                <ExternalLink className="w-3 h-3 text-slate-400 group-hover/link:text-blue-500 shrink-0 ml-1" />
                              </a>
                            ))}
                        </div>
                      )}
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Action Toolbar on Hover & Voice Assistant */}
          {!isStreaming && !isError && (
            <div className="flex items-center gap-2 mt-1.5 text-[11px] text-slate-400 dark:text-slate-500">
              {/* Voice Assistant Speak Button */}
              {!isUser && message.content && (
                <button
                  onClick={handleToggleSpeak}
                  className={`flex items-center gap-1 transition-colors px-2 py-0.5 rounded-md ${
                    isSpeaking
                      ? 'bg-indigo-100 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400 font-semibold animate-pulse'
                      : 'hover:text-slate-700 dark:hover:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                  }`}
                  title={isSpeaking ? 'Stop Voice Assistant' : 'Play aloud with Voice Assistant'}
                >
                  {isSpeaking ? (
                    <>
                      <VolumeX className="w-3 h-3 text-red-500" />
                      <span>Stop Voice</span>
                    </>
                  ) : (
                    <>
                      <Volume2 className="w-3 h-3" />
                      <span>Voice Assistant</span>
                    </>
                  )}
                </button>
              )}

              {/* Copy message button */}
              <button
                onClick={handleCopyMessage}
                className="flex items-center gap-1 hover:text-slate-700 dark:hover:text-slate-300 transition-colors p-1 rounded"
                title="Copy text"
              >
                {copied ? <Check className="w-3 h-3 text-emerald-500" /> : <Copy className="w-3 h-3" />}
                <span>{copied ? 'Copied' : 'Copy'}</span>
              </button>
            </div>
          )}
        </div>

        {isUser && (
          <div className="w-8 h-8 rounded-xl bg-slate-200 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 flex items-center justify-center shrink-0 text-slate-700 dark:text-slate-300 shadow-sm mt-0.5">
            <User className="w-4 h-4" />
          </div>
        )}
      </div>

      {/* Expanded Image Zoom Modal */}
      {expandedImage && (
        <div
          onClick={() => setExpandedImage(null)}
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4 cursor-pointer"
        >
          <div className="relative max-w-4xl max-h-[90vh] overflow-hidden rounded-2xl shadow-2xl">
            <button
              onClick={() => setExpandedImage(null)}
              className="absolute top-3 right-3 p-1.5 rounded-full bg-black/60 text-white hover:bg-black/90 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
            <img
              src={expandedImage}
              alt="Expanded preview"
              className="max-h-[85vh] w-auto object-contain rounded-2xl"
            />
          </div>
        </div>
      )}
    </>
  );
};
