import React, { useState, useRef, useEffect, useCallback } from 'react';
import { Message, ChatSession, Persona, FileAttachment } from '../../types/chat';
import { PERSONAS } from '../../data/personas';
import { ChatMessageItem } from './ChatMessageItem';
import { ChatInput } from './ChatInput';
import { SessionSidebar } from './SessionSidebar';
import { ModelSettingsModal } from './ModelSettingsModal';
import { LiveVoiceModal } from '../LiveAudio/LiveVoiceModal';
import { recordMessageUsage } from '../../utils/usageTracker';
import { getStoredVoiceSettings, speakText } from '../../utils/voiceAssistant';

interface ChatStudioProps {
  isSettingsOpen: boolean;
  onCloseSettings: () => void;
  onOpenSettings: () => void;
  onUpdateActiveTitle?: (title: string) => void;
  externalPrompt?: string;
  onClearExternalPrompt?: () => void;
}

export const ChatStudio: React.FC<ChatStudioProps> = ({
  isSettingsOpen,
  onCloseSettings,
  onOpenSettings,
  onUpdateActiveTitle,
  externalPrompt,
  onClearExternalPrompt,
}) => {
  const [selectedPersona, setSelectedPersona] = useState<Persona>(PERSONAS[0]);
  const [isLiveVoiceOpen, setIsLiveVoiceOpen] = useState(false);

  // Initial session using Gemini 3.5 Flash by default
  const [sessions, setSessions] = useState<ChatSession[]>(() => [
    {
      id: 'session-default',
      title: 'Welcome to Nova AI',
      createdAt: Date.now(),
      updatedAt: Date.now(),
      personaId: PERSONAS[0].id,
      systemInstruction: PERSONAS[0].systemPrompt,
      temperature: 0.7,
      model: 'gemini-3.5-flash',
      useGoogleSearch: false,
      messages: [
        {
          id: 'welcome-msg',
          role: 'assistant',
          content: PERSONAS[0].initialMessage,
          timestamp: Date.now(),
          status: 'complete',
        },
      ],
    },
  ]);

  const [activeSessionId, setActiveSessionId] = useState<string>('session-default');
  const [isStreaming, setIsStreaming] = useState<boolean>(false);

  const abortControllerRef = useRef<AbortController | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const activeSession =
    sessions.find((s) => s.id === activeSessionId) || sessions[0];

  // Scroll to bottom when messages update
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [activeSession?.messages]);

  // Handle external prompts (e.g. from calendar or quick actions)
  useEffect(() => {
    if (externalPrompt && externalPrompt.trim()) {
      handleSendMessage(externalPrompt);
      if (onClearExternalPrompt) onClearExternalPrompt();
    }
  }, [externalPrompt]);

  // Sync active title with parent navigation
  useEffect(() => {
    if (activeSession && onUpdateActiveTitle) {
      onUpdateActiveTitle(activeSession.title);
    }
  }, [activeSession?.title, onUpdateActiveTitle]);

  const handleSelectSession = (id: string) => {
    setActiveSessionId(id);
    const session = sessions.find((s) => s.id === id);
    if (session) {
      const persona = PERSONAS.find((p) => p.id === session.personaId) || PERSONAS[0];
      setSelectedPersona(persona);
    }
  };

  const handleNewSession = () => {
    const newSession: ChatSession = {
      id: `session-${Date.now()}`,
      title: 'New Conversation',
      createdAt: Date.now(),
      updatedAt: Date.now(),
      personaId: selectedPersona.id,
      systemInstruction: selectedPersona.systemPrompt,
      temperature: 0.7,
      model: 'gemini-3.5-flash',
      useGoogleSearch: false,
      messages: [
        {
          id: `welcome-${Date.now()}`,
          role: 'assistant',
          content: selectedPersona.initialMessage,
          timestamp: Date.now(),
          status: 'complete',
        },
      ],
    };

    setSessions((prev) => [newSession, ...prev]);
    setActiveSessionId(newSession.id);
  };

  const handleDeleteSession = (id: string) => {
    if (sessions.length <= 1) return;
    const remaining = sessions.filter((s) => s.id !== id);
    setSessions(remaining);
    if (activeSessionId === id) {
      setActiveSessionId(remaining[0].id);
    }
  };

  const handleExportSession = (session: ChatSession) => {
    const content = JSON.stringify(session, null, 2);
    const blob = new Blob([content], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${session.title.toLowerCase().replace(/[^a-z0-9]/g, '-')}-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleSelectPersona = (persona: Persona) => {
    setSelectedPersona(persona);
    setSessions((prev) =>
      prev.map((s) =>
        s.id === activeSessionId
          ? {
              ...s,
              personaId: persona.id,
              systemInstruction: persona.systemPrompt,
              messages: [
                ...s.messages,
                {
                  id: `persona-switch-${Date.now()}`,
                  role: 'assistant',
                  content: `Switched mode to **${persona.name}** (${persona.roleTitle}). ${persona.initialMessage}`,
                  timestamp: Date.now(),
                  status: 'complete',
                },
              ],
            }
          : s
      )
    );
  };

  const handleToggleGoogleSearch = () => {
    setSessions((prev) =>
      prev.map((s) =>
        s.id === activeSessionId
          ? {
              ...s,
              useGoogleSearch: !s.useGoogleSearch,
              // If enabling Search Grounding, ensure model is gemini-3.5-flash
              model: !s.useGoogleSearch ? 'gemini-3.5-flash' : s.model,
            }
          : s
      )
    );
  };

  const handleStopStreaming = useCallback(() => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
      abortControllerRef.current = null;
    }
    setIsStreaming(false);

    setSessions((prev) =>
      prev.map((s) =>
        s.id === activeSessionId
          ? {
              ...s,
              messages: s.messages.map((m) =>
                m.status === 'streaming' ? { ...m, status: 'complete' } : m
              ),
            }
          : s
      )
    );
  }, [activeSessionId]);

  const handleSendMessage = async (text: string, attachments?: FileAttachment[]) => {
    if ((!text.trim() && (!attachments || attachments.length === 0)) || isStreaming) {
      return;
    }

    const userMessage: Message = {
      id: `user-${Date.now()}`,
      role: 'user',
      content: text,
      timestamp: Date.now(),
      status: 'complete',
      attachments: attachments && attachments.length > 0 ? attachments : undefined,
    };

    const assistantMsgId = `assistant-${Date.now()}`;
    const assistantMessage: Message = {
      id: assistantMsgId,
      role: 'assistant',
      content: '',
      timestamp: Date.now(),
      status: 'streaming',
    };

    // Auto-generate title if default
    let sessionTitle = activeSession.title;
    if (activeSession.title === 'New Conversation' || activeSession.title === 'Welcome to Nova AI') {
      sessionTitle = text.slice(0, 36) + (text.length > 36 ? '...' : '');
    }

    const updatedMessages = [...activeSession.messages, userMessage];

    setSessions((prev) =>
      prev.map((s) =>
        s.id === activeSessionId
          ? {
              ...s,
              title: sessionTitle,
              updatedAt: Date.now(),
              messages: [...s.messages, userMessage, assistantMessage],
            }
          : s
      )
    );

    setIsStreaming(true);
    const controller = new AbortController();
    abortControllerRef.current = controller;
    const startTime = Date.now();

    try {
      const requestPayload = {
        messages: updatedMessages.map((m) => ({
          role: m.role,
          content: m.content,
          attachments: m.attachments,
        })),
        systemInstruction: activeSession.systemInstruction || selectedPersona.systemPrompt,
        temperature: activeSession.temperature ?? 0.7,
        model: activeSession.model || 'gemini-3.5-flash',
        useGoogleSearch: Boolean(activeSession.useGoogleSearch),
        stream: true,
      };

      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(requestPayload),
        signal: controller.signal,
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.error || `HTTP ${response.status}: Failed to generate response`);
      }

      const reader = response.body?.getReader();
      if (!reader) {
        throw new Error('ReadableStream not supported on this browser');
      }

      const decoder = new TextDecoder('utf-8');
      let buffer = '';
      let accumulatedText = '';
      let latestGroundingMetadata: any = null;

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n');
        buffer = lines.pop() || '';

        for (const line of lines) {
          const trimmed = line.trim();
          if (trimmed.startsWith('data: ')) {
            const dataStr = trimmed.slice(6);
            try {
              const parsed = JSON.parse(dataStr);

              if (parsed.error) {
                throw new Error(parsed.error);
              }

              if (parsed.groundingMetadata) {
                latestGroundingMetadata = parsed.groundingMetadata;
              }

              if (parsed.chunk) {
                accumulatedText += parsed.chunk;
                setSessions((prev) =>
                  prev.map((s) =>
                    s.id === activeSessionId
                      ? {
                          ...s,
                          messages: s.messages.map((m) =>
                            m.id === assistantMsgId
                              ? {
                                  ...m,
                                  content: accumulatedText,
                                  status: 'streaming',
                                  groundingMetadata: latestGroundingMetadata || m.groundingMetadata,
                                }
                              : m
                          ),
                        }
                      : s
                  )
                );
              }

              if (parsed.done) {
                const latency = Date.now() - startTime;
                recordMessageUsage(accumulatedText.length);
                const voiceSettings = getStoredVoiceSettings();
                if (voiceSettings.autoSpeak && accumulatedText) {
                  speakText(accumulatedText);
                }
                setSessions((prev) =>
                  prev.map((s) =>
                    s.id === activeSessionId
                      ? {
                          ...s,
                          messages: s.messages.map((m) =>
                            m.id === assistantMsgId
                              ? {
                                  ...m,
                                  status: 'complete',
                                  latencyMs: latency,
                                  groundingMetadata: parsed.groundingMetadata || latestGroundingMetadata,
                                }
                              : m
                          ),
                        }
                      : s
                  )
                );
              }
            } catch (jsonErr) {
              // Ignore non-json lines
            }
          }
        }
      }
    } catch (err: any) {
      if (err.name === 'AbortError') {
        console.log('Stream generation aborted by user');
      } else {
        console.error('Chat error:', err);
        setSessions((prev) =>
          prev.map((s) =>
            s.id === activeSessionId
              ? {
                  ...s,
                  messages: s.messages.map((m) =>
                    m.id === assistantMsgId
                      ? {
                          ...m,
                          status: 'error',
                          error: err.message || 'An error occurred while generating response',
                        }
                      : m
                  ),
                }
              : s
          )
        );
      }
    } finally {
      setIsStreaming(false);
      abortControllerRef.current = null;
    }
  };

  const handleRetry = (message: Message) => {
    const messageIndex = activeSession.messages.findIndex((m) => m.id === message.id);
    if (messageIndex === -1) return;

    let previousUserMessage: Message | null = null;
    for (let i = messageIndex - 1; i >= 0; i--) {
      if (activeSession.messages[i].role === 'user') {
        previousUserMessage = activeSession.messages[i];
        break;
      }
    }

    if (previousUserMessage) {
      const remainingMessages = activeSession.messages.slice(0, messageIndex);
      setSessions((prev) =>
        prev.map((s) =>
          s.id === activeSessionId ? { ...s, messages: remainingMessages } : s
        )
      );

      handleSendMessage(previousUserMessage.content, previousUserMessage.attachments);
    }
  };

  return (
    <div className="flex h-[calc(100vh-61px)] w-full overflow-hidden bg-slate-50 dark:bg-slate-950 transition-colors">
      {/* Sessions and Chats Sidebar */}
      <SessionSidebar
        sessions={sessions}
        activeSessionId={activeSessionId}
        onSelectSession={handleSelectSession}
        onNewSession={handleNewSession}
        onDeleteSession={handleDeleteSession}
        onExportSession={handleExportSession}
        onOpenSettings={onOpenSettings}
      />

      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col h-full overflow-hidden">
        {/* Scrollable Message Thread */}
        <div className="flex-1 overflow-y-auto divide-y divide-slate-100/70 dark:divide-slate-900/60 pb-4">
          {activeSession.messages.map((message) => (
            <ChatMessageItem
              key={message.id}
              message={message}
              onRetry={handleRetry}
            />
          ))}
          <div ref={messagesEndRef} />
        </div>

        {/* Chat Input Bar */}
        <ChatInput
          onSend={handleSendMessage}
          onStop={handleStopStreaming}
          isStreaming={isStreaming}
          selectedPersona={selectedPersona}
          personas={PERSONAS}
          onSelectPersona={handleSelectPersona}
          suggestedPrompts={selectedPersona.suggestedPrompts}
          activeModel={activeSession.model || 'gemini-3.5-flash'}
          onOpenSettings={onOpenSettings}
          useGoogleSearch={Boolean(activeSession.useGoogleSearch)}
          onToggleGoogleSearch={handleToggleGoogleSearch}
          onOpenLiveVoice={() => setIsLiveVoiceOpen(true)}
        />
      </div>

      {/* Preferences & Model Settings Modal */}
      {isSettingsOpen && (
        <ModelSettingsModal
          model={activeSession.model || 'gemini-3.5-flash'}
          onModelChange={(newModel) => {
            setSessions((prev) =>
              prev.map((s) => (s.id === activeSessionId ? { ...s, model: newModel } : s))
            );
          }}
          temperature={activeSession.temperature ?? 0.7}
          onTemperatureChange={(temp) => {
            setSessions((prev) =>
              prev.map((s) => (s.id === activeSessionId ? { ...s, temperature: temp } : s))
            );
          }}
          systemInstruction={activeSession.systemInstruction || selectedPersona.systemPrompt}
          onSystemInstructionChange={(prompt) => {
            setSessions((prev) =>
              prev.map((s) => (s.id === activeSessionId ? { ...s, systemInstruction: prompt } : s))
            );
          }}
          onClose={onCloseSettings}
          useGoogleSearch={Boolean(activeSession.useGoogleSearch)}
          onToggleGoogleSearch={handleToggleGoogleSearch}
        />
      )}

      {/* Feature 3: Gemini 3.8 Live API Real-Time Voice Conversation */}
      {isLiveVoiceOpen && (
        <LiveVoiceModal
          onClose={() => setIsLiveVoiceOpen(false)}
          systemPrompt={activeSession.systemInstruction}
        />
      )}
    </div>
  );
};
