import React, { useMemo } from 'react';
import { marked } from 'marked';
import { Check, Copy } from 'lucide-react';

interface MarkdownViewProps {
  content: string;
}

export const MarkdownView: React.FC<MarkdownViewProps> = ({ content }) => {
  const [copiedIndex, setCopiedIndex] = React.useState<number | null>(null);

  // Parse markdown
  const html = useMemo(() => {
    try {
      return marked.parse(content || '', {
        gfm: true,
        breaks: true,
      }) as string;
    } catch (e) {
      return content;
    }
  }, [content]);

  // Extract code snippets for quick copy
  const handleCopyCode = (codeText: string, index: number) => {
    navigator.clipboard.writeText(codeText);
    setCopiedIndex(index);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  // Enhance rendered HTML with copy buttons using standard event delegation
  const containerRef = React.useRef<HTMLDivElement>(null);

  React.useEffect(() => {
    if (!containerRef.current) return;

    const pres = containerRef.current.querySelectorAll('pre');
    pres.forEach((pre, idx) => {
      // If header already attached, skip
      if (pre.parentElement?.classList.contains('code-block-wrapper')) return;

      const code = pre.querySelector('code');
      const textToCopy = code?.innerText || pre.innerText;

      // Extract language class if any
      const langClass = Array.from(code?.classList || []).find((c) =>
        c.startsWith('language-')
      );
      const language = langClass ? langClass.replace('language-', '') : 'code';

      // Create wrapper
      const wrapper = document.createElement('div');
      wrapper.className =
        'code-block-wrapper my-3 rounded-lg overflow-hidden border border-slate-700/80 bg-slate-950';

      // Create header bar
      const header = document.createElement('div');
      header.className =
        'flex items-center justify-between px-3 py-1.5 bg-slate-900 border-b border-slate-800 text-xs text-slate-400 font-mono';

      const langSpan = document.createElement('span');
      langSpan.innerText = language;

      const copyBtn = document.createElement('button');
      copyBtn.className =
        'flex items-center gap-1 text-slate-400 hover:text-slate-100 transition-colors text-[11px] py-0.5 px-1.5 rounded hover:bg-slate-800';
      copyBtn.innerHTML = `<span>Copy</span>`;
      copyBtn.onclick = (e) => {
        e.stopPropagation();
        navigator.clipboard.writeText(textToCopy);
        copyBtn.innerHTML = `<span class="text-emerald-400">Copied!</span>`;
        setTimeout(() => {
          copyBtn.innerHTML = `<span>Copy</span>`;
        }, 2000);
      };

      header.appendChild(langSpan);
      header.appendChild(copyBtn);

      pre.parentNode?.insertBefore(wrapper, pre);
      wrapper.appendChild(header);
      wrapper.appendChild(pre);

      pre.className = 'p-3 m-0 overflow-x-auto text-xs font-mono text-slate-200 bg-slate-950/70';
    });
  }, [html]);

  return (
    <div
      ref={containerRef}
      className="prose-chat text-sm text-slate-200 leading-relaxed break-words"
      dangerouslySetInnerHTML={{ __html: html }}
    />
  );
};
