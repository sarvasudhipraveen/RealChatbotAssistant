import React, { useState } from 'react';
import { X, Sliders, Cpu, Sun, Moon, Volume2, Mic, Check, Bot, Globe, Palette, Coffee, Flame } from 'lucide-react';
import { useTheme } from '../../context/ThemeContext';
import { useAuth } from '../../context/AuthContext';
import {
  getStoredVoiceSettings,
  saveStoredVoiceSettings,
  speakText,
  stopSpeaking,
} from '../../utils/voiceAssistant';

interface ModelSettingsModalProps {
  model: string;
  onModelChange: (model: string) => void;
  temperature: number;
  onTemperatureChange: (temp: number) => void;
  systemInstruction: string;
  onSystemInstructionChange: (prompt: string) => void;
  onClose: () => void;
  useGoogleSearch?: boolean;
  onToggleGoogleSearch?: () => void;
}

const AVAILABLE_MODELS = [
  { id: 'gemini-3.5-flash', name: 'Google Gemini 3.5 Flash (General & Search Grounding)', desc: 'General multi-turn conversations and live Google Search Grounding' },
  { id: 'gemini-3.1-pro-preview', name: 'Google Gemini 3.1 Pro (Complex Reasoning)', desc: 'Advanced coding, mathematics, deep reasoning & complex STEM tasks' },
  { id: 'gemini-3.1-flash-lite', name: 'Google Gemini 3.1 Flash Lite (Ultra Fast)', desc: 'High-speed, low-latency immediate responses' },
  { id: 'gemini-3.8-flash', name: 'Google Gemini 3.8 Flash (Multimodal)', desc: 'Photos, images, and document file comprehension' },
  { id: 'openai/gpt-4o', name: 'OpenAI GPT-4o (Vision & Multimodal)', desc: 'Photo analysis, vision, reasoning & writing' },
  { id: 'anthropic/claude-3.5-sonnet', name: 'Claude 3.5 Sonnet (OpenRouter)', desc: 'Nuanced writing & deep reasoning' },
];

export const ModelSettingsModal: React.FC<ModelSettingsModalProps> = ({
  model,
  onModelChange,
  temperature,
  onTemperatureChange,
  systemInstruction,
  onSystemInstructionChange,
  onClose,
  useGoogleSearch = false,
  onToggleGoogleSearch,
}) => {
  const { theme, setTheme, availableThemes } = useTheme();
  const { aiConfig, setAiName } = useAuth();
  const [tempAiName, setTempAiName] = useState(aiConfig.name || 'Nova AI');
  const [isSavedAiName, setIsSavedAiName] = useState(false);
  const [voiceSettings, setVoiceSettings] = useState(getStoredVoiceSettings());
  const [isPlayingTest, setIsPlayingTest] = useState(false);

  const handleToggleAutoSpeak = () => {
    const updated = { ...voiceSettings, autoSpeak: !voiceSettings.autoSpeak };
    setVoiceSettings(updated);
    saveStoredVoiceSettings(updated);
  };

  const handleTestVoice = () => {
    if (isPlayingTest) {
      stopSpeaking();
      setIsPlayingTest(false);
      return;
    }
    speakText(
      'Hello! Your Voice Assistant is active and ready to assist you with files, photos, and answers.',
      voiceSettings,
      () => setIsPlayingTest(true),
      () => setIsPlayingTest(false),
      () => setIsPlayingTest(false)
    );
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-md overflow-hidden shadow-2xl flex flex-col transition-colors max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950">
          <div className="flex items-center gap-2">
            <Sliders className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
            <h3 className="text-sm font-semibold text-slate-900 dark:text-white">Chat Preferences</h3>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-700 dark:hover:text-white p-1 rounded-lg hover:bg-slate-200 dark:hover:bg-slate-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 space-y-4 text-xs text-slate-700 dark:text-slate-300 overflow-y-auto">
          {/* AI Name Customization */}
          <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 space-y-2">
            <label className="block text-slate-800 dark:text-slate-200 font-semibold flex items-center gap-1.5">
              <Bot className="w-4 h-4 text-indigo-500" />
              <span>Customize AI Assistant Name</span>
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                value={tempAiName}
                onChange={(e) => {
                  setTempAiName(e.target.value);
                  setIsSavedAiName(false);
                }}
                placeholder="e.g. Jarvis, Athena, Aura..."
                className="flex-1 px-3 py-1.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:border-indigo-500 font-medium"
              />
              <button
                type="button"
                onClick={() => {
                  if (tempAiName.trim()) {
                    setAiName(tempAiName.trim());
                    setIsSavedAiName(true);
                    setTimeout(() => setIsSavedAiName(false), 2000);
                  }
                }}
                className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg font-medium transition-colors"
              >
                {isSavedAiName ? 'Saved!' : 'Save Name'}
              </button>
            </div>
            <p className="text-[10px] text-slate-400">
              The AI will address itself as &ldquo;{tempAiName || 'Nova'}&rdquo; in chats and voice responses.
            </p>
          </div>

          {/* Appearance Theme Selector with Warm Palettes */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="block text-slate-800 dark:text-slate-300 font-medium text-xs flex items-center gap-1.5">
                <Palette className="w-3.5 h-3.5 text-amber-500" />
                <span>Color Themes & Warm Palettes</span>
              </label>
              <span className="text-[10px] text-amber-600 dark:text-amber-400 font-semibold px-2 py-0.5 rounded-full bg-amber-50 dark:bg-amber-950/60 border border-amber-200 dark:border-amber-800">
                Warm Colors Included
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
              {availableThemes.map((t) => {
                const isSelected = theme === t.id;
                return (
                  <button
                    key={t.id}
                    type="button"
                    onClick={() => setTheme(t.id)}
                    className={`flex flex-col text-left p-2.5 rounded-xl border transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-amber-50/80 dark:bg-amber-950/40 border-amber-500 text-amber-950 dark:text-amber-100 shadow-xs ring-1 ring-amber-500/50'
                        : 'bg-slate-50/50 dark:bg-slate-950/50 border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-900'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1.5">
                      <div className="flex items-center gap-2">
                        <div
                          className="w-5 h-5 rounded-lg border border-slate-300 dark:border-slate-700 flex items-center justify-center shadow-xs shrink-0"
                          style={{ backgroundColor: t.previewBg }}
                        >
                          <div
                            className="w-2 h-2 rounded-full"
                            style={{ backgroundColor: t.previewAccent }}
                          />
                        </div>
                        <span className="font-bold text-xs">{t.name}</span>
                      </div>
                      {isSelected && (
                        <Check className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400 shrink-0" />
                      )}
                    </div>
                    <p className="text-[10px] text-slate-400 line-clamp-2 leading-relaxed">
                      {t.description}
                    </p>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Google Search Grounding Setting */}
          {onToggleGoogleSearch && (
            <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 space-y-1.5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Globe className="w-4 h-4 text-blue-500" />
                  <span className="font-semibold text-slate-800 dark:text-slate-200">
                    Google Search Grounding
                  </span>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={useGoogleSearch}
                    onChange={onToggleGoogleSearch}
                    className="sr-only peer"
                  />
                  <div className="w-9 h-5 bg-slate-200 peer-focus:outline-none rounded-full peer dark:bg-slate-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all dark:border-slate-600 peer-checked:bg-blue-600"></div>
                </label>
              </div>
              <p className="text-[10px] text-slate-500 dark:text-slate-400">
                Grounds responses with real-time web results from Google Search using gemini-3.5-flash for accurate, up-to-date facts.
              </p>
            </div>
          )}

          {/* Voice Assistant Settings */}
          <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Volume2 className="w-4 h-4 text-indigo-500" />
                <span className="font-semibold text-slate-800 dark:text-slate-200">Voice Assistant</span>
              </div>
              <button
                type="button"
                onClick={handleTestVoice}
                className="text-[11px] text-indigo-600 dark:text-indigo-400 hover:underline font-medium"
              >
                {isPlayingTest ? 'Stop Test' : 'Test Voice'}
              </button>
            </div>

            <label className="flex items-center justify-between cursor-pointer pt-1">
              <div>
                <p className="font-medium text-slate-700 dark:text-slate-300 text-[11px]">
                  Auto-Speak Responses
                </p>
                <p className="text-[10px] text-slate-400">
                  Read out AI answers automatically
                </p>
              </div>
              <input
                type="checkbox"
                checked={voiceSettings.autoSpeak}
                onChange={handleToggleAutoSpeak}
                className="w-4 h-4 accent-indigo-600 rounded cursor-pointer"
              />
            </label>
          </div>

          {/* Model Selector */}
          <div>
            <label className="block text-slate-800 dark:text-slate-300 font-medium mb-1.5 flex items-center gap-1.5">
              <Cpu className="w-3.5 h-3.5 text-indigo-500 dark:text-indigo-400" />
              <span>AI Model</span>
            </label>
            <div className="space-y-1.5">
              {AVAILABLE_MODELS.map((m) => (
                <button
                  key={m.id}
                  type="button"
                  onClick={() => onModelChange(m.id)}
                  className={`w-full text-left p-2.5 rounded-lg border transition-all flex flex-col ${
                    model === m.id
                      ? 'bg-indigo-50 dark:bg-indigo-600/20 border-indigo-300 dark:border-indigo-500/50 text-indigo-900 dark:text-white font-medium'
                      : 'bg-slate-50/70 dark:bg-slate-950/70 border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800/60'
                  }`}
                >
                  <span className="font-semibold text-xs">{m.name}</span>
                  <span className="text-[11px] text-slate-500 dark:text-slate-400">{m.desc}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Creativity / Temperature */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-slate-800 dark:text-slate-300 font-medium">Creativity Level</label>
              <span className="text-indigo-600 dark:text-indigo-400 font-semibold tabular-nums">
                {temperature < 0.4 ? 'Focused & Direct' : temperature < 1.0 ? 'Balanced' : 'Highly Creative'}
              </span>
            </div>
            <input
              type="range"
              min="0"
              max="1.5"
              step="0.05"
              value={temperature}
              onChange={(e) => onTemperatureChange(parseFloat(e.target.value))}
              className="w-full accent-indigo-600 bg-slate-200 dark:bg-slate-800 h-1.5 rounded-lg cursor-pointer"
            />
          </div>

          {/* Custom Personality / Instructions */}
          <div>
            <label className="block text-slate-800 dark:text-slate-300 font-medium mb-1">
              Custom Persona or Instructions
            </label>
            <textarea
              value={systemInstruction}
              onChange={(e) => onSystemInstructionChange(e.target.value)}
              rows={2}
              placeholder="Tell the AI how you want it to behave..."
              className="w-full p-2.5 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-slate-900 dark:text-slate-100 placeholder-slate-400 dark:placeholder-slate-600 focus:outline-none focus:border-indigo-500 text-xs leading-relaxed"
            />
          </div>
        </div>

        {/* Footer */}
        <div className="px-5 py-3 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-lg transition-colors"
          >
            Save Changes
          </button>
        </div>
      </div>
    </div>
  );
};
