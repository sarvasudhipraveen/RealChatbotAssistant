import React, { useState, useRef } from 'react';
import { motion } from 'framer-motion';
import {
  Wand2,
  Sparkles,
  Upload,
  Download,
  Image as ImageIcon,
  Film,
  RefreshCw,
  AlertCircle,
  Copy,
  Check,
  Sliders,
  ZoomIn,
  X,
  Layers,
} from 'lucide-react';

interface ImageStudioProps {
  onSendToVideoStudio?: (imageDataUrl: string, mimeType?: string) => void;
  initialEditImage?: string | null;
}

interface GeneratedImageItem {
  id: string;
  url: string;
  prompt: string;
  mode: 'create' | 'edit';
  aspectRatio: string;
  timestamp: number;
}

const ASPECT_RATIOS = [
  { id: '1:1', label: '1:1 Square', desc: 'Instagram, Avatars' },
  { id: '16:9', label: '16:9 Landscape', desc: 'Desktop, YouTube' },
  { id: '9:16', label: '9:16 Portrait', desc: 'Stories, Reels' },
  { id: '4:3', label: '4:3 Standard', desc: 'Photo print' },
  { id: '3:4', label: '3:4 Portrait', desc: 'Mobile wall' },
];

const SUGGESTIONS = [
  'Futuristic cyberpunk city street reflecting neon lights on wet asphalt, cinematic lighting, 8k',
  'Watercolor illustration of a wise owl perched on ancient mossy books in an enchanted library',
  'Cozy minimalist Japanese tea room overlooking a tranquil bonsai garden in gentle rain',
  'Isometric 3D render of a floating glass greenhouse floating among pastel clouds',
  'Majestic snow leopard resting on Himalayan mountain summit during golden hour sunset',
];

const EDIT_SUGGESTIONS = [
  'Add glowing ethereal fireflies and magical purple mist around the subject',
  'Change the background to a dramatic starry nebula galaxy',
  'Transform the scene into a snowy winter wonderland with soft falling snow',
  'Add cinematic golden hour warm sunbeams filtering through the scene',
  'Apply a retro 1980s synthwave vaporwave aesthetic with neon cyan and magenta glow',
];

export const ImageStudio: React.FC<ImageStudioProps> = ({
  onSendToVideoStudio,
  initialEditImage,
}) => {
  const [activeTab, setActiveTab] = useState<'create' | 'edit'>(initialEditImage ? 'edit' : 'create');
  const [prompt, setPrompt] = useState('');
  const [editPrompt, setEditPrompt] = useState('');
  const [aspectRatio, setAspectRatio] = useState('1:1');
  const [imageSize, setImageSize] = useState('1K');
  const [sourceImage, setSourceImage] = useState<string | null>(initialEditImage || null);
  const [sourceMimeType, setSourceMimeType] = useState('image/png');
  const [isGenerating, setIsGenerating] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [currentResult, setCurrentResult] = useState<GeneratedImageItem | null>(null);
  const [history, setHistory] = useState<GeneratedImageItem[]>([]);
  const [copied, setCopied] = useState(false);
  const [zoomImage, setZoomImage] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setSourceMimeType(file.type || 'image/png');
    const reader = new FileReader();
    reader.onload = (event) => {
      setSourceImage(event.target?.result as string);
      setActiveTab('edit');
    };
    reader.readAsDataURL(file);
  };

  const handleGenerate = async (mode: 'create' | 'edit') => {
    const targetPrompt = mode === 'create' ? prompt : editPrompt;
    if (!targetPrompt.trim() && mode === 'create') return;
    if (!sourceImage && mode === 'edit') {
      setErrorMessage('Please upload an image to edit.');
      return;
    }

    setIsGenerating(true);
    setErrorMessage(null);

    try {
      const payload: any = {
        prompt: targetPrompt,
        aspectRatio,
        imageSize,
      };

      if (mode === 'edit' && sourceImage) {
        payload.image = {
          data: sourceImage,
          mimeType: sourceMimeType,
        };
      }

      const res = await fetch('/api/generate-image', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      const data = await res.json();

      if (!res.ok || !data.success) {
        throw new Error(data.error || 'Failed to generate image');
      }

      const newItem: GeneratedImageItem = {
        id: `img-${Date.now()}`,
        url: data.imageUrl,
        prompt: targetPrompt,
        mode,
        aspectRatio,
        timestamp: Date.now(),
      };

      setCurrentResult(newItem);
      setHistory((prev) => [newItem, ...prev]);
    } catch (err: any) {
      console.error('Image generation error:', err);
      setErrorMessage(err.message || 'Error communicating with gemini-3.1-flash-image-preview');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleCopy = (url: string) => {
    navigator.clipboard.writeText(url);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="h-[calc(100vh-61px)] flex flex-col lg:flex-row overflow-hidden bg-slate-50 dark:bg-slate-950 transition-colors">
      {/* Left Control Panel */}
      <div className="w-full lg:w-[460px] xl:w-[500px] border-b lg:border-b-0 lg:border-r border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 flex flex-col h-full overflow-y-auto">
        {/* Header */}
        <div className="p-5 border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-2.5 mb-1.5">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-purple-600 to-indigo-600 text-white flex items-center justify-center shadow-md shadow-purple-500/20">
              <Wand2 className="w-4 h-4" />
            </div>
            <div>
              <h1 className="font-bold text-base text-slate-900 dark:text-white flex items-center gap-2">
                <span>Image Studio</span>
                <span className="text-[10px] px-2 py-0.5 rounded-full font-medium bg-purple-50 dark:bg-purple-950/60 text-purple-600 dark:text-purple-400 border border-purple-200 dark:border-purple-800">
                  gemini-3.1-flash-image-preview
                </span>
              </h1>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Generate novel images or edit existing photos with text prompts
              </p>
            </div>
          </div>

          {/* Mode Switcher Tabs */}
          <div className="flex bg-slate-100 dark:bg-slate-800 p-1 rounded-2xl mt-4">
            <button
              onClick={() => setActiveTab('create')}
              className={`relative flex-1 py-1.5 text-xs font-semibold rounded-xl transition-colors flex items-center justify-center gap-1.5 cursor-pointer ${
                activeTab === 'create'
                  ? 'text-indigo-600 dark:text-indigo-300'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              {activeTab === 'create' && (
                <motion.div
                  layoutId="activeImageStudioTab"
                  className="absolute inset-0 bg-white dark:bg-slate-700 rounded-xl shadow-xs"
                  transition={{ type: 'spring', stiffness: 500, damping: 35 }}
                />
              )}
              <span className="relative z-10 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5" />
                <span>Create with Prompt</span>
              </span>
            </button>
            <button
              onClick={() => setActiveTab('edit')}
              className={`relative flex-1 py-1.5 text-xs font-semibold rounded-xl transition-colors flex items-center justify-center gap-1.5 cursor-pointer ${
                activeTab === 'edit'
                  ? 'text-purple-600 dark:text-purple-300'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              {activeTab === 'edit' && (
                <motion.div
                  layoutId="activeImageStudioTab"
                  className="absolute inset-0 bg-white dark:bg-slate-700 rounded-xl shadow-xs"
                  transition={{ type: 'spring', stiffness: 500, damping: 35 }}
                />
              )}
              <span className="relative z-10 flex items-center gap-1.5">
                <Layers className="w-3.5 h-3.5" />
                <span>Edit Existing Photo</span>
              </span>
            </button>
          </div>
        </div>

        {/* Form Body */}
        <div className="p-5 flex-1 space-y-5">
          {activeTab === 'create' ? (
            /* CREATE MODE */
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                  Text Prompt
                </label>
                <textarea
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  placeholder="Describe the image you want to create in vivid detail..."
                  rows={4}
                  className="w-full text-xs p-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-800/50 text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-purple-500/20 focus:border-purple-500 transition-all resize-none"
                />
              </div>

              {/* Suggestions */}
              <div>
                <span className="text-[11px] font-semibold text-slate-500 dark:text-slate-400 flex items-center gap-1 mb-1.5">
                  <Sparkles className="w-3 h-3 text-purple-500" />
                  <span>Try a prompt idea:</span>
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {SUGGESTIONS.slice(0, 3).map((item, idx) => (
                    <button
                      key={idx}
                      onClick={() => setPrompt(item)}
                      className="text-[10px] text-left p-1.5 px-2 rounded-lg bg-slate-100 dark:bg-slate-800/80 hover:bg-purple-50 dark:hover:bg-purple-950/40 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700 hover:border-purple-300 dark:hover:border-purple-800 transition-colors line-clamp-1"
                    >
                      &ldquo;{item}&rdquo;
                    </button>
                  ))}
                </div>
              </div>
            </div>
          ) : (
            /* EDIT MODE */
            <div className="space-y-4">
              {/* Upload source image */}
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                  Source Image to Edit
                </label>
                <input
                  type="file"
                  ref={fileInputRef}
                  accept="image/*"
                  onChange={handleFileUpload}
                  className="hidden"
                />

                {sourceImage ? (
                  <div className="relative rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-700 group">
                    <img
                      src={sourceImage}
                      alt="Source to edit"
                      className="w-full h-44 object-cover"
                    />
                    <div className="absolute inset-0 bg-slate-950/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                      <button
                        onClick={() => fileInputRef.current?.click()}
                        className="p-2 rounded-xl bg-white text-slate-800 text-xs font-medium flex items-center gap-1 shadow-lg"
                      >
                        <RefreshCw className="w-3.5 h-3.5" />
                        <span>Change</span>
                      </button>
                      <button
                        onClick={() => setSourceImage(null)}
                        className="p-2 rounded-xl bg-red-600 text-white text-xs font-medium flex items-center gap-1 shadow-lg"
                      >
                        <X className="w-3.5 h-3.5" />
                        <span>Remove</span>
                      </button>
                    </div>
                  </div>
                ) : (
                  <button
                    onClick={() => fileInputRef.current?.click()}
                    className="w-full h-36 border-2 border-dashed border-slate-300 dark:border-slate-700 rounded-2xl flex flex-col items-center justify-center p-4 hover:border-purple-500 hover:bg-purple-50/40 dark:hover:bg-purple-950/20 transition-all text-slate-500 dark:text-slate-400 group"
                  >
                    <Upload className="w-7 h-7 mb-2 text-slate-400 group-hover:text-purple-500 transition-colors" />
                    <span className="text-xs font-semibold text-slate-700 dark:text-slate-200">
                      Upload an image to edit
                    </span>
                    <span className="text-[10px] text-slate-400 mt-0.5">
                      PNG, JPG, WebP supported
                    </span>
                  </button>
                )}
              </div>

              {/* Edit Instruction Prompt */}
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                  Edit Instructions
                </label>
                <textarea
                  value={editPrompt}
                  onChange={(e) => setEditPrompt(e.target.value)}
                  placeholder="e.g. Add a glowing aurora borealis in the sky, turn into watercolor painting, etc."
                  rows={3}
                  className="w-full text-xs p-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-800/50 text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-purple-500/20 focus:border-purple-500 transition-all resize-none"
                />
              </div>

              {/* Edit suggestions */}
              <div>
                <span className="text-[11px] font-semibold text-slate-500 dark:text-slate-400 flex items-center gap-1 mb-1.5">
                  <Wand2 className="w-3 h-3 text-purple-500" />
                  <span>Edit ideas:</span>
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {EDIT_SUGGESTIONS.slice(0, 3).map((item, idx) => (
                    <button
                      key={idx}
                      onClick={() => setEditPrompt(item)}
                      className="text-[10px] text-left p-1.5 px-2 rounded-lg bg-slate-100 dark:bg-slate-800/80 hover:bg-purple-50 dark:hover:bg-purple-950/40 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700 hover:border-purple-300 dark:hover:border-purple-800 transition-colors line-clamp-1"
                    >
                      &ldquo;{item}&rdquo;
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Aspect Ratio Options */}
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
              Aspect Ratio
            </label>
            <div className="grid grid-cols-3 gap-1.5">
              {ASPECT_RATIOS.map((item) => (
                <motion.button
                  whileHover={{ scale: 1.03 }}
                  whileTap={{ scale: 0.95 }}
                  key={item.id}
                  onClick={() => setAspectRatio(item.id)}
                  className={`p-2 rounded-xl text-left border transition-all cursor-pointer ${
                    aspectRatio === item.id
                      ? 'border-purple-500 bg-purple-50 dark:bg-purple-950/50 text-purple-700 dark:text-purple-300 font-semibold'
                      : 'border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 text-slate-600 dark:text-slate-400 hover:bg-slate-100'
                  }`}
                >
                  <p className="text-xs font-semibold">{item.label}</p>
                  <p className="text-[9px] text-slate-400 truncate">{item.desc}</p>
                </motion.button>
              ))}
            </div>
          </div>

          {/* Error notice */}
          {errorMessage && (
            <div className="p-3 rounded-xl bg-red-50 dark:bg-red-950/50 border border-red-200 dark:border-red-900/60 text-xs text-red-600 dark:text-red-400 flex items-start gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
              <div>
                <p className="font-semibold">Generation Notice</p>
                <p className="text-[11px] mt-0.5">{errorMessage}</p>
              </div>
            </div>
          )}

          {/* Generate Button */}
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.96 }}
            onClick={() => handleGenerate(activeTab)}
            disabled={isGenerating || (activeTab === 'create' ? !prompt.trim() : !sourceImage)}
            className="w-full py-3 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 disabled:opacity-50 text-white font-semibold text-xs shadow-md shadow-purple-600/20 transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            {isGenerating ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" />
                <span>Generating with gemini-3.1-flash-image-preview...</span>
              </>
            ) : (
              <>
                <Wand2 className="w-4 h-4" />
                <span>{activeTab === 'create' ? 'Generate Image' : 'Apply Image Edits'}</span>
              </>
            )}
          </motion.button>
        </div>
      </div>

      {/* Right Canvas: Current Result & History Showcase */}
      <div className="flex-1 p-6 overflow-y-auto flex flex-col items-center justify-start">
        {currentResult ? (
          <div className="w-full max-w-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl shadow-xl overflow-hidden animate-fade-in">
            {/* Top Info Bar */}
            <div className="p-4 px-6 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-purple-50 dark:bg-purple-950/60 text-purple-600 dark:text-purple-400 border border-purple-200 dark:border-purple-800">
                  {currentResult.mode === 'create' ? 'New Generation' : 'Edited Photo'} • {currentResult.aspectRatio}
                </span>
                <p className="text-xs text-slate-700 dark:text-slate-300 font-medium mt-1 line-clamp-1">
                  &ldquo;{currentResult.prompt}&rdquo;
                </p>
              </div>

              <div className="flex items-center gap-1.5">
                <button
                  onClick={() => setZoomImage(currentResult.url)}
                  className="p-2 rounded-xl text-slate-500 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                  title="Zoom Fullscreen"
                >
                  <ZoomIn className="w-4 h-4" />
                </button>
                <a
                  href={currentResult.url}
                  download={`gemini-image-${currentResult.id}.png`}
                  className="p-2 rounded-xl text-slate-500 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                  title="Download Image"
                >
                  <Download className="w-4 h-4" />
                </a>
              </div>
            </div>

            {/* Main Image Display */}
            <div className="p-6 flex items-center justify-center bg-slate-950/5 dark:bg-slate-950/40">
              <img
                src={currentResult.url}
                alt={currentResult.prompt}
                className="max-h-[500px] w-auto object-contain rounded-2xl shadow-lg border border-slate-200 dark:border-slate-800"
              />
            </div>

            {/* Quick Actions Bar */}
            <div className="p-4 px-6 bg-slate-50 dark:bg-slate-950/50 border-t border-slate-100 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                {/* Send to Video Animator */}
                {onSendToVideoStudio && (
                  <motion.button
                    whileHover={{ scale: 1.04 }}
                    whileTap={{ scale: 0.94 }}
                    onClick={() => onSendToVideoStudio(currentResult.url, 'image/png')}
                    className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white shadow-sm shadow-orange-500/20 transition-all cursor-pointer"
                  >
                    <Film className="w-3.5 h-3.5" />
                    <span>Animate into Video with Veo</span>
                  </motion.button>
                )}

                {/* Edit this image further */}
                <motion.button
                  whileHover={{ scale: 1.04 }}
                  whileTap={{ scale: 0.94 }}
                  onClick={() => {
                    setSourceImage(currentResult.url);
                    setActiveTab('edit');
                  }}
                  className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-medium bg-slate-200 dark:bg-slate-800 text-slate-800 dark:text-slate-200 hover:bg-slate-300 dark:hover:bg-slate-700 transition-colors cursor-pointer"
                >
                  <Wand2 className="w-3.5 h-3.5 text-purple-500" />
                  <span>Edit Further</span>
                </motion.button>
              </div>

              {/* Copy URL */}
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.92 }}
                onClick={() => handleCopy(currentResult.url)}
                className="flex items-center gap-1.5 text-xs text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 transition-colors cursor-pointer"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copied Data' : 'Copy Image URL'}</span>
              </motion.button>
            </div>
          </div>
        ) : (
          /* Empty state */
          <div className="max-w-md my-auto text-center p-8 border border-dashed border-slate-300 dark:border-slate-800 rounded-3xl">
            <div className="w-14 h-14 rounded-2xl bg-purple-50 dark:bg-purple-950/60 text-purple-600 dark:text-purple-400 flex items-center justify-center mx-auto mb-3 shadow-sm">
              <ImageIcon className="w-7 h-7" />
            </div>
            <h3 className="font-bold text-slate-800 dark:text-slate-200 text-sm">
              Canvas Ready
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              Enter a prompt or upload an existing image on the left to start generating with gemini-3.1-flash-image-preview.
            </p>
          </div>
        )}

        {/* Recent History Grid */}
        {history.length > 1 && (
          <div className="w-full max-w-2xl mt-8">
            <h4 className="text-xs font-bold text-slate-700 dark:text-slate-300 mb-3 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-purple-500" />
              <span>Recent Creations in This Session</span>
            </h4>
            <div className="grid grid-cols-3 sm:grid-cols-4 gap-3">
              {history.map((item) => (
                <div
                  key={item.id}
                  onClick={() => setCurrentResult(item)}
                  className={`group relative rounded-xl overflow-hidden border cursor-pointer aspect-square bg-slate-900 transition-all ${
                    currentResult?.id === item.id
                      ? 'ring-2 ring-purple-500 border-transparent shadow-md'
                      : 'border-slate-200 dark:border-slate-800 hover:opacity-90'
                  }`}
                >
                  <img
                    src={item.url}
                    alt={item.prompt}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-slate-950/60 opacity-0 group-hover:opacity-100 transition-opacity p-2 flex flex-col justify-end">
                    <p className="text-[10px] text-white line-clamp-2 leading-tight">
                      {item.prompt}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Fullscreen Zoom Modal */}
      {zoomImage && (
        <div
          onClick={() => setZoomImage(null)}
          className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-4 animate-fade-in"
        >
          <button
            onClick={() => setZoomImage(null)}
            className="absolute top-4 right-4 p-2 text-white/70 hover:text-white rounded-full bg-slate-900/60"
          >
            <X className="w-6 h-6" />
          </button>
          <img
            src={zoomImage}
            alt="Fullscreen preview"
            className="max-h-[90vh] max-w-[90vw] object-contain rounded-2xl shadow-2xl"
          />
        </div>
      )}
    </div>
  );
};
