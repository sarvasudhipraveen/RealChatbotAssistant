import React, { useEffect, useRef, useState } from 'react';
import {
  X,
  Mic,
  MicOff,
  Volume2,
  Sparkles,
  PhoneOff,
  Radio,
  Settings2,
  AlertCircle,
} from 'lucide-react';
import { pcmToBase64, LiveAudioPlayer } from '../../utils/liveAudio';
import { useAuth } from '../../context/AuthContext';

interface LiveVoiceModalProps {
  onClose: () => void;
  systemPrompt?: string;
}

const VOICES = [
  { id: 'Zephyr', name: 'Zephyr', tone: 'Warm & balanced' },
  { id: 'Puck', name: 'Puck', tone: 'Playful & upbeat' },
  { id: 'Charon', name: 'Charon', tone: 'Deep & calm' },
  { id: 'Kore', name: 'Kore', tone: 'Gentle & clear' },
  { id: 'Fenrir', name: 'Fenrir', tone: 'Crisp & energetic' },
];

export const LiveVoiceModal: React.FC<LiveVoiceModalProps> = ({
  onClose,
  systemPrompt,
}) => {
  const { aiConfig, user } = useAuth();
  const [selectedVoice, setSelectedVoice] = useState('Zephyr');
  const [status, setStatus] = useState<'connecting' | 'listening' | 'speaking' | 'interrupted' | 'error'>('connecting');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isMuted, setIsMuted] = useState(false);
  const [userAudioLevel, setUserAudioLevel] = useState(0);
  const [aiAudioLevel, setAiAudioLevel] = useState(0);
  const [liveTranscript, setLiveTranscript] = useState<string[]>([]);

  const wsRef = useRef<WebSocket | null>(null);
  const playerRef = useRef<LiveAudioPlayer | null>(null);
  const inputAudioCtxRef = useRef<AudioContext | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const isMutedRef = useRef(false);

  isMutedRef.current = isMuted;

  useEffect(() => {
    let isMounted = true;
    const player = new LiveAudioPlayer();
    playerRef.current = player;

    async function initLiveSession() {
      try {
        setStatus('connecting');
        setErrorMessage(null);

        // 1. Request microphone access
        const stream = await navigator.mediaDevices.getUserMedia({
          audio: {
            channelCount: 1,
            sampleRate: 16000,
            echoCancellation: true,
            noiseSuppression: true,
            autoGainControl: true,
          },
        });
        if (!isMounted) {
          stream.getTracks().forEach((t) => t.stop());
          return;
        }
        mediaStreamRef.current = stream;

        // 2. Setup 16kHz audio input context for Gemini Live
        const AudioCtxClass = window.AudioContext || (window as any).webkitAudioContext;
        const inputCtx = new AudioCtxClass({ sampleRate: 16000 });
        inputAudioCtxRef.current = inputCtx;

        const source = inputCtx.createMediaStreamSource(stream);
        const processor = inputCtx.createScriptProcessor(2048, 1, 1);
        source.connect(processor);
        processor.connect(inputCtx.destination);

        // 3. Setup WebSocket connection to backend /live
        const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
        const wsUrl = `${protocol}//${window.location.host}/live`;
        const ws = new WebSocket(wsUrl);
        wsRef.current = ws;

        ws.onopen = () => {
          if (!isMounted) return;
          setStatus('listening');

          // Send setup configuration
          const assistantName = aiConfig.name || 'Nova';
          const greetingPrompt = systemPrompt || `You are ${assistantName}, a real-time conversational AI. The user's name is ${user?.name || 'Friend'}. Keep responses conversational, concise, natural, and friendly.`;

          ws.send(
            JSON.stringify({
              setup: {
                voiceName: selectedVoice,
                systemInstruction: greetingPrompt,
              },
            })
          );
        };

        ws.onmessage = (event) => {
          if (!isMounted) return;
          try {
            const data = JSON.parse(event.data);

            if (data.interrupted) {
              player.stopAll();
              setStatus('listening');
              setAiAudioLevel(0);
            }

            if (data.audio) {
              setStatus('speaking');
              player.playChunk(data.audio, (level) => {
                if (isMounted) setAiAudioLevel(level);
              });
            }

            if (data.text) {
              setLiveTranscript((prev) => [...prev.slice(-4), data.text]);
            }

            if (data.error) {
              console.error('Gemini Live server error:', data.error);
              setErrorMessage(data.error);
              setStatus('error');
            }
          } catch (e) {
            console.error('Error parsing live WS message:', e);
          }
        };

        ws.onerror = (e) => {
          console.error('WebSocket error:', e);
          if (isMounted) {
            setErrorMessage('Unable to connect to real-time voice server.');
            setStatus('error');
          }
        };

        ws.onclose = () => {
          if (isMounted && status !== 'error') {
            setStatus('connecting');
          }
        };

        // 4. Capture microphone buffer and send to Gemini Live
        processor.onaudioprocess = (e) => {
          if (!isMounted || isMutedRef.current || ws.readyState !== WebSocket.OPEN) {
            setUserAudioLevel(0);
            return;
          }

          const channelData = e.inputBuffer.getChannelData(0);

          // Compute user mic RMS level for visualizer
          let sumSquares = 0;
          for (let i = 0; i < channelData.length; i++) {
            sumSquares += channelData[i] * channelData[i];
          }
          const rms = Math.sqrt(sumSquares / channelData.length);
          setUserAudioLevel(Math.min(1, rms * 4));

          const base64Audio = pcmToBase64(channelData);
          ws.send(
            JSON.stringify({
              audio: base64Audio,
            })
          );
        };
      } catch (err: any) {
        console.error('Failed to start Live Audio session:', err);
        if (isMounted) {
          setErrorMessage(err.message || 'Microphone access denied or audio unavailable.');
          setStatus('error');
        }
      }
    }

    initLiveSession();

    return () => {
      isMounted = false;
      if (wsRef.current) {
        try {
          wsRef.current.close();
        } catch {}
      }
      if (inputAudioCtxRef.current) {
        try {
          inputAudioCtxRef.current.close();
        } catch {}
      }
      if (mediaStreamRef.current) {
        mediaStreamRef.current.getTracks().forEach((t) => t.stop());
      }
      if (playerRef.current) {
        playerRef.current.close();
      }
    };
  }, [selectedVoice]);

  // Interrupt model speaking
  const handleInterrupt = () => {
    if (playerRef.current) {
      playerRef.current.stopAll();
    }
    setAiAudioLevel(0);
    setStatus('listening');
    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({ interrupt: true }));
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl shadow-2xl overflow-hidden flex flex-col transition-all">
        {/* Top Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-indigo-600 to-violet-500 text-white flex items-center justify-center shadow-md shadow-indigo-500/20">
              <Radio className="w-4 h-4 animate-pulse" />
            </div>
            <div>
              <h2 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
                <span>{aiConfig.name || 'Nova'} Live Conversation</span>
                <span className="text-[10px] px-2 py-0.5 rounded-full font-medium bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 border border-indigo-200 dark:border-indigo-800">
                  gemini-3.8-live
                </span>
              </h2>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">
                Ultra-low latency real-time voice streaming
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            title="Close voice conversation"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Center Canvas / Audio Visualizer Waves */}
        <div className="flex-1 flex flex-col items-center justify-center p-8 min-h-[260px] relative overflow-hidden bg-radial from-indigo-500/10 via-transparent to-transparent">
          {/* Animated Pulsing Rings */}
          <div className="relative flex items-center justify-center">
            {/* Outer animated orb */}
            <div
              className={`absolute rounded-full transition-all duration-150 ${
                status === 'speaking'
                  ? 'bg-gradient-to-tr from-indigo-500/20 to-purple-500/30'
                  : status === 'listening'
                  ? 'bg-gradient-to-tr from-emerald-500/20 to-teal-500/20'
                  : 'bg-slate-500/10'
              }`}
              style={{
                width: `${160 + (status === 'speaking' ? aiAudioLevel : userAudioLevel) * 90}px`,
                height: `${160 + (status === 'speaking' ? aiAudioLevel : userAudioLevel) * 90}px`,
              }}
            />

            {/* Inner dynamic core */}
            <div
              className={`w-32 h-32 rounded-full flex items-center justify-center shadow-xl border transition-all duration-200 ${
                status === 'speaking'
                  ? 'bg-gradient-to-tr from-indigo-600 to-violet-600 border-indigo-400 text-white shadow-indigo-500/40 scale-105'
                  : status === 'listening'
                  ? 'bg-slate-900 border-emerald-500/50 text-emerald-400 shadow-emerald-500/20'
                  : 'bg-slate-800 border-slate-700 text-slate-400'
              }`}
            >
              {status === 'speaking' ? (
                <Volume2 className="w-10 h-10 animate-bounce" />
              ) : status === 'listening' ? (
                <Mic className="w-10 h-10 animate-pulse" />
              ) : (
                <Sparkles className="w-10 h-10" />
              )}
            </div>
          </div>

          {/* Status Label */}
          <div className="mt-6 text-center">
            <span
              className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold ${
                status === 'speaking'
                  ? 'bg-indigo-100 dark:bg-indigo-950/80 text-indigo-700 dark:text-indigo-300'
                  : status === 'listening'
                  ? 'bg-emerald-100 dark:bg-emerald-950/80 text-emerald-700 dark:text-emerald-300'
                  : status === 'error'
                  ? 'bg-red-100 dark:bg-red-950/80 text-red-700 dark:text-red-300'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400'
              }`}
            >
              <span
                className={`w-2 h-2 rounded-full ${
                  status === 'speaking'
                    ? 'bg-indigo-600 animate-ping'
                    : status === 'listening'
                    ? 'bg-emerald-500 animate-pulse'
                    : status === 'error'
                    ? 'bg-red-500'
                    : 'bg-slate-400'
                }`}
              />
              {status === 'speaking'
                ? `${aiConfig.name || 'Nova'} is speaking...`
                : status === 'listening'
                ? isMuted
                  ? 'Microphone Muted'
                  : 'Listening to you... Speak naturally!'
                : status === 'error'
                ? 'Connection Error'
                : 'Connecting to Gemini Live...'}
            </span>

            {errorMessage && (
              <p className="text-xs text-red-500 dark:text-red-400 mt-2 max-w-xs flex items-center justify-center gap-1 mx-auto">
                <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                <span>{errorMessage}</span>
              </p>
            )}

            {/* Live Transcript Preview */}
            {liveTranscript.length > 0 && (
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-3 max-w-sm line-clamp-2 italic">
                &ldquo;{liveTranscript[liveTranscript.length - 1]}&rdquo;
              </p>
            )}
          </div>
        </div>

        {/* Voice Selector & Controls Bar */}
        <div className="p-4 bg-slate-50 dark:bg-slate-950/60 border-t border-slate-200 dark:border-slate-800 flex flex-col gap-3">
          {/* Voice Choice */}
          <div className="flex items-center justify-between text-xs">
            <span className="text-slate-600 dark:text-slate-400 font-medium flex items-center gap-1">
              <Settings2 className="w-3.5 h-3.5 text-indigo-500" />
              <span>Gemini Live Voice:</span>
            </span>
            <div className="flex gap-1">
              {VOICES.map((v) => (
                <button
                  key={v.id}
                  onClick={() => setSelectedVoice(v.id)}
                  className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-all ${
                    selectedVoice === v.id
                      ? 'bg-indigo-600 text-white shadow-xs'
                      : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700'
                  }`}
                  title={`${v.name} (${v.tone})`}
                >
                  {v.name}
                </button>
              ))}
            </div>
          </div>

          {/* Bottom Action Buttons */}
          <div className="flex items-center justify-center gap-3 pt-1">
            {/* Mute/Unmute Mic */}
            <button
              onClick={() => setIsMuted(!isMuted)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl text-xs font-semibold transition-all ${
                isMuted
                  ? 'bg-amber-500 text-white shadow-md shadow-amber-500/20'
                  : 'bg-slate-200 dark:bg-slate-800 text-slate-800 dark:text-slate-200 hover:bg-slate-300 dark:hover:bg-slate-700'
              }`}
            >
              {isMuted ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4 text-emerald-500" />}
              <span>{isMuted ? 'Unmute Mic' : 'Mute Mic'}</span>
            </button>

            {/* Interrupt AI */}
            {status === 'speaking' && (
              <button
                onClick={handleInterrupt}
                className="flex items-center gap-2 px-4 py-2.5 rounded-2xl text-xs font-semibold bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-300 border border-indigo-300 dark:border-indigo-800 hover:bg-indigo-100 transition-all active:scale-95"
              >
                <span>Tap to Interrupt</span>
              </button>
            )}

            {/* End Call */}
            <button
              onClick={onClose}
              className="flex items-center gap-2 px-5 py-2.5 rounded-2xl text-xs font-semibold bg-red-600 hover:bg-red-500 text-white shadow-md shadow-red-600/20 active:scale-95 transition-all"
            >
              <PhoneOff className="w-4 h-4" />
              <span>End Call</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
