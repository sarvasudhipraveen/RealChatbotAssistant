import React, { useState } from 'react';
import { motion } from 'framer-motion';
import {
  PlusCircle,
  Settings2,
  Sparkles,
  Sun,
  Moon,
  BarChart3,
  Calendar,
  LogOut,
  ChevronDown,
  User,
  Bot,
  MessageSquare,
  Wand2,
  Film,
  LayoutGrid,
  Palette,
  Flame,
  Coffee,
  Check,
} from 'lucide-react';
import { useTheme } from '../context/ThemeContext';
import { useAuth } from '../context/AuthContext';

interface NavigationProps {
  activeTitle?: string;
  activeView: 'chat' | 'image' | 'video';
  onSelectView: (view: 'chat' | 'image' | 'video') => void;
  onNewChat: () => void;
  onOpenSettings: () => void;
  onOpenUsage: () => void;
  onOpenCalendar: () => void;
  onOpenApps: () => void;
}

export const Navigation: React.FC<NavigationProps> = ({
  activeTitle = 'Conversation',
  activeView,
  onSelectView,
  onNewChat,
  onOpenSettings,
  onOpenUsage,
  onOpenCalendar,
  onOpenApps,
}) => {
  const { theme, setTheme, availableThemes } = useTheme();
  const { user, aiConfig, logout } = useAuth();
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [showThemeMenu, setShowThemeMenu] = useState(false);

  return (
    <header className="flex items-center justify-between px-3 md:px-6 py-2.5 border-b border-slate-200 dark:border-slate-800 bg-white/95 dark:bg-slate-950/95 backdrop-blur-md sticky top-0 z-40 transition-colors">
      {/* Zone 1: Customized AI Name Wordmark & Apps Suite Trigger */}
      <div className="flex items-center gap-3">
        <motion.button
          whileHover={{ scale: 1.06, rotate: 6 }}
          whileTap={{ scale: 0.92, rotate: -6 }}
          onClick={onOpenApps}
          className="flex items-center gap-2 p-1.5 px-2.5 rounded-xl bg-gradient-to-r from-indigo-500/10 via-purple-500/10 to-pink-500/10 hover:from-indigo-500/20 hover:to-pink-500/20 border border-indigo-200/60 dark:border-indigo-800/60 text-indigo-600 dark:text-indigo-400 text-xs font-bold transition-all shadow-xs cursor-pointer"
          title="Open Apps & Studios Suite"
        >
          <LayoutGrid className="w-4 h-4 animate-pulse" />
          <span className="hidden sm:inline">Apps</span>
        </motion.button>

        <div className="flex items-center gap-2">
          <span className="w-2.5 h-2.5 rounded-full bg-indigo-500 shadow-[0_0_8px_rgba(99,102,241,0.8)]" />
          <span className="text-base md:text-lg font-bold tracking-tight text-slate-900 dark:text-white truncate max-w-[140px] md:max-w-[200px]">
            {aiConfig.name || 'Nova AI'}
          </span>
        </div>
      </div>

      {/* Zone 2: Fluid Animated Studio Switcher Tabs with Framer Motion layoutId */}
      <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-900/80 p-1 rounded-2xl border border-slate-200/80 dark:border-slate-800">
        <button
          onClick={() => onSelectView('chat')}
          className={`relative flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition-colors cursor-pointer ${
            activeView === 'chat'
              ? 'text-indigo-600 dark:text-indigo-400'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
          }`}
          title="Chat Studio (Gemini 3.5 Flash, Voice, Search Grounding)"
        >
          {activeView === 'chat' && (
            <motion.div
              layoutId="activeStudioPill"
              className="absolute inset-0 bg-white dark:bg-slate-800 rounded-xl shadow-xs"
              transition={{ type: 'spring', stiffness: 500, damping: 35 }}
            />
          )}
          <span className="relative z-10 flex items-center gap-1.5">
            <MessageSquare className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Chat</span>
          </span>
        </button>

        <button
          onClick={() => onSelectView('image')}
          className={`relative flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition-colors cursor-pointer ${
            activeView === 'image'
              ? 'text-purple-600 dark:text-purple-400'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
          }`}
          title="Image Studio (gemini-3.1-flash-image-preview)"
        >
          {activeView === 'image' && (
            <motion.div
              layoutId="activeStudioPill"
              className="absolute inset-0 bg-white dark:bg-slate-800 rounded-xl shadow-xs"
              transition={{ type: 'spring', stiffness: 500, damping: 35 }}
            />
          )}
          <span className="relative z-10 flex items-center gap-1.5">
            <Wand2 className="w-3.5 h-3.5 text-purple-500" />
            <span className="hidden sm:inline">Image Studio</span>
          </span>
        </button>

        <button
          onClick={() => onSelectView('video')}
          className={`relative flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition-colors cursor-pointer ${
            activeView === 'video'
              ? 'text-amber-600 dark:text-amber-400'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
          }`}
          title="Veo Video Animator (veo-3.1-fast-generate-preview 16:9 / 9:16)"
        >
          {activeView === 'video' && (
            <motion.div
              layoutId="activeStudioPill"
              className="absolute inset-0 bg-white dark:bg-slate-800 rounded-xl shadow-xs"
              transition={{ type: 'spring', stiffness: 500, damping: 35 }}
            />
          )}
          <span className="relative z-10 flex items-center gap-1.5">
            <Film className="w-3.5 h-3.5 text-amber-500" />
            <span className="hidden sm:inline">Veo Video</span>
          </span>
        </button>
      </div>

      {/* Zone 3: Primary Actions with Tactile Click Physics */}
      <div className="flex items-center gap-1.5 md:gap-2">
        {/* Usage Analytics Button */}
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.93 }}
          onClick={onOpenUsage}
          className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white rounded-xl hover:bg-slate-100 dark:hover:bg-slate-900 border border-slate-200 dark:border-slate-800 transition-colors font-medium cursor-pointer"
          title="Daily Usage Analytics & Bar Graph"
        >
          <BarChart3 className="w-4 h-4 text-indigo-500" />
          <span className="hidden sm:inline">Usage</span>
        </motion.button>

        {/* Calendar & Schedule Button */}
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.93 }}
          onClick={onOpenCalendar}
          className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white rounded-xl hover:bg-slate-100 dark:hover:bg-slate-900 border border-slate-200 dark:border-slate-800 transition-colors font-medium cursor-pointer"
          title="Calendar & Planner"
        >
          <Calendar className="w-4 h-4 text-indigo-500" />
          <span className="hidden sm:inline">Calendar</span>
        </motion.button>

        {/* Warm Theme Palette Selector */}
        <div className="relative">
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.93 }}
            onClick={() => {
              setShowThemeMenu(!showThemeMenu);
              setShowUserMenu(false);
            }}
            className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs text-slate-700 dark:text-slate-200 hover:text-slate-900 dark:hover:text-white rounded-xl hover:bg-slate-100 dark:hover:bg-slate-900 border border-slate-200 dark:border-slate-800 transition-colors font-medium cursor-pointer"
            title="Choose Theme & Warm Color Palette"
            aria-label="Theme palette"
          >
            {theme === 'warm-espresso' && <Coffee className="w-3.5 h-3.5 text-amber-500" />}
            {theme === 'warm-amber' && <Sun className="w-3.5 h-3.5 text-amber-500" />}
            {theme === 'warm-sunset' && <Flame className="w-3.5 h-3.5 text-orange-500" />}
            {theme === 'dark' && <Moon className="w-3.5 h-3.5 text-indigo-400" />}
            {theme === 'light' && <Sun className="w-3.5 h-3.5 text-slate-600" />}
            <span className="hidden md:inline capitalize font-semibold text-[11px]">
              {theme === 'warm-espresso'
                ? 'Warm Espresso'
                : theme === 'warm-amber'
                ? 'Warm Sand'
                : theme === 'warm-sunset'
                ? 'Sunset'
                : theme === 'dark'
                ? 'Dark'
                : 'Light'}
            </span>
          </motion.button>

          {showThemeMenu && (
            <div className="absolute right-0 mt-2 w-64 bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 p-2 z-50 animate-fade-in text-xs space-y-1">
              <div className="px-2.5 py-1.5 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
                <span className="font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
                  <Palette className="w-3.5 h-3.5 text-amber-500" />
                  <span>Color Themes</span>
                </span>
                <span className="text-[10px] text-amber-600 dark:text-amber-400 font-semibold px-1.5 py-0.5 rounded-full bg-amber-50 dark:bg-amber-950/60 border border-amber-200 dark:border-amber-800">
                  Warm Palettes
                </span>
              </div>

              {availableThemes.map((t) => {
                const isSelected = theme === t.id;
                return (
                  <button
                    key={t.id}
                    onClick={() => {
                      setTheme(t.id);
                      setShowThemeMenu(false);
                    }}
                    className={`w-full flex items-center justify-between p-2 rounded-xl text-left transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-amber-50 dark:bg-amber-950/40 text-amber-900 dark:text-amber-200 border border-amber-300 dark:border-amber-700/60 shadow-xs'
                        : 'hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <div
                        className="w-5 h-5 rounded-lg border border-slate-300 dark:border-slate-700 flex items-center justify-center shadow-xs shrink-0"
                        style={{ backgroundColor: t.previewBg }}
                      >
                        <div
                          className="w-2 h-2 rounded-full"
                          style={{ backgroundColor: t.previewAccent }}
                        />
                      </div>
                      <div>
                        <p className="font-semibold text-xs leading-tight">{t.name}</p>
                        <p className="text-[10px] text-slate-400 line-clamp-1">{t.description}</p>
                      </div>
                    </div>
                    {isSelected && <Check className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400 shrink-0" />}
                  </button>
                );
              })}
            </div>
          )}
        </div>

        {/* Preferences / Settings */}
        <motion.button
          whileHover={{ scale: 1.08, rotate: 15 }}
          whileTap={{ scale: 0.92 }}
          onClick={onOpenSettings}
          className="p-2 text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white rounded-xl hover:bg-slate-100 dark:hover:bg-slate-900 border border-slate-200 dark:border-slate-800 transition-colors cursor-pointer"
          title="Model & Assistant Settings"
        >
          <Settings2 className="w-4 h-4" />
        </motion.button>

        {/* User Profile Dropdown */}
        <div className="relative">
          <motion.button
            whileHover={{ scale: 1.04 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => setShowUserMenu(!showUserMenu)}
            className="flex items-center gap-2 p-1 pl-2 pr-2 rounded-xl border border-slate-200 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-900 transition-colors cursor-pointer"
          >
            <div className="w-6 h-6 rounded-full bg-indigo-600 text-white flex items-center justify-center text-xs font-semibold uppercase">
              {user?.name ? user.name[0] : 'U'}
            </div>
            <span className="text-xs font-medium text-slate-700 dark:text-slate-300 hidden md:inline truncate max-w-[80px]">
              {user?.name || 'User'}
            </span>
            <ChevronDown className="w-3 h-3 text-slate-400" />
          </motion.button>

          {showUserMenu && (
            <div className="absolute right-0 mt-2 w-48 bg-white dark:bg-slate-900 rounded-2xl shadow-xl border border-slate-200 dark:border-slate-800 py-1 z-50 animate-fade-in text-xs">
              <div className="px-3 py-2 border-b border-slate-100 dark:border-slate-800">
                <p className="font-semibold text-slate-800 dark:text-slate-200">{user?.name}</p>
                <p className="text-[10px] text-slate-400 truncate">{user?.email}</p>
              </div>

              <button
                onClick={() => {
                  setShowUserMenu(false);
                  onOpenSettings();
                }}
                className="w-full text-left px-3 py-2 text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800 flex items-center gap-2"
              >
                <Settings2 className="w-3.5 h-3.5" />
                <span>Assistant Config</span>
              </button>

              <button
                onClick={() => {
                  setShowUserMenu(false);
                  onOpenUsage();
                }}
                className="w-full text-left px-3 py-2 text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800 flex items-center gap-2"
              >
                <BarChart3 className="w-3.5 h-3.5" />
                <span>Usage Stats</span>
              </button>

              <div className="border-t border-slate-100 dark:border-slate-800 my-1" />

              <button
                onClick={() => {
                  setShowUserMenu(false);
                  logout();
                }}
                className="w-full text-left px-3 py-2 text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/40 flex items-center gap-2"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Log out</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
