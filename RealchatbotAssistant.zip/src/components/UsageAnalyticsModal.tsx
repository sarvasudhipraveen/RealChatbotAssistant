import React, { useState } from 'react';
import { X, BarChart3, TrendingUp, MessageSquare, Zap, Calendar, Sparkles } from 'lucide-react';
import { getDailyUsage, DayUsage } from '../utils/usageTracker';

interface UsageAnalyticsModalProps {
  onClose: () => void;
}

export const UsageAnalyticsModal: React.FC<UsageAnalyticsModalProps> = ({ onClose }) => {
  const [metric, setMetric] = useState<'messages' | 'tokens'>('messages');
  const [hoveredDay, setHoveredDay] = useState<DayUsage | null>(null);
  const data = getDailyUsage();

  const maxVal = Math.max(...data.map((d) => (metric === 'messages' ? d.messages : d.tokens)), 10);
  const totalMessages = data.reduce((acc, d) => acc + d.messages, 0);
  const totalTokens = data.reduce((acc, d) => acc + d.tokens, 0);
  const today = data[data.length - 1];
  const avgDaily = Math.round(metric === 'messages' ? totalMessages / data.length : totalTokens / data.length);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-xl overflow-hidden shadow-2xl flex flex-col text-slate-900 dark:text-slate-100 transition-colors">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-indigo-600/10 dark:bg-indigo-600/20 text-indigo-600 dark:text-indigo-400 flex items-center justify-center">
              <BarChart3 className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-semibold text-slate-900 dark:text-white">Daily Usage Analytics</h3>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">Activity breakdown over the last 7 days</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-700 dark:hover:text-white p-1 rounded-lg hover:bg-slate-200 dark:hover:bg-slate-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 space-y-5">
          {/* Key Metrics Grid */}
          <div className="grid grid-cols-3 gap-3">
            <div className="p-3 rounded-xl bg-slate-100 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60">
              <div className="flex items-center gap-1.5 text-xs text-slate-500 dark:text-slate-400 mb-1">
                <Calendar className="w-3.5 h-3.5 text-indigo-500" />
                <span>Today</span>
              </div>
              <div className="text-lg font-bold text-slate-900 dark:text-white">
                {metric === 'messages' ? today.messages : today.tokens.toLocaleString()}
              </div>
              <div className="text-[10px] text-emerald-600 dark:text-emerald-400 flex items-center gap-0.5 mt-0.5">
                <TrendingUp className="w-3 h-3" />
                <span>Active session</span>
              </div>
            </div>

            <div className="p-3 rounded-xl bg-slate-100 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60">
              <div className="flex items-center gap-1.5 text-xs text-slate-500 dark:text-slate-400 mb-1">
                <MessageSquare className="w-3.5 h-3.5 text-indigo-500" />
                <span>7-Day Total</span>
              </div>
              <div className="text-lg font-bold text-slate-900 dark:text-white">
                {metric === 'messages' ? totalMessages : totalTokens.toLocaleString()}
              </div>
              <div className="text-[10px] text-slate-500">
                {metric === 'messages' ? 'prompts & replies' : 'estimated tokens'}
              </div>
            </div>

            <div className="p-3 rounded-xl bg-slate-100 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60">
              <div className="flex items-center gap-1.5 text-xs text-slate-500 dark:text-slate-400 mb-1">
                <Zap className="w-3.5 h-3.5 text-amber-500" />
                <span>Daily Avg</span>
              </div>
              <div className="text-lg font-bold text-slate-900 dark:text-white">
                {avgDaily.toLocaleString()}
              </div>
              <div className="text-[10px] text-slate-500">per day</div>
            </div>
          </div>

          {/* Bar Graph Section */}
          <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800">
            {/* Graph Controls */}
            <div className="flex items-center justify-between mb-4">
              <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                Everyday {metric === 'messages' ? 'Messages' : 'Tokens'}
              </span>
              <div className="flex items-center bg-slate-200 dark:bg-slate-800 rounded-lg p-0.5 text-xs">
                <button
                  onClick={() => setMetric('messages')}
                  className={`px-2.5 py-1 rounded-md text-[11px] font-medium transition-all ${
                    metric === 'messages'
                      ? 'bg-white dark:bg-indigo-600 text-slate-900 dark:text-white shadow-sm'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                  }`}
                >
                  Messages
                </button>
                <button
                  onClick={() => setMetric('tokens')}
                  className={`px-2.5 py-1 rounded-md text-[11px] font-medium transition-all ${
                    metric === 'tokens'
                      ? 'bg-white dark:bg-indigo-600 text-slate-900 dark:text-white shadow-sm'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                  }`}
                >
                  Tokens
                </button>
              </div>
            </div>

            {/* The Interactive Everyday Bar Graph */}
            <div className="h-44 flex items-end justify-between gap-2.5 pt-6 pb-2 px-2">
              {data.map((item, index) => {
                const currentVal = metric === 'messages' ? item.messages : item.tokens;
                const heightPct = Math.max(12, Math.round((currentVal / maxVal) * 100));
                const isToday = index === data.length - 1;
                const isHovered = hoveredDay?.date === item.date;

                return (
                  <div
                    key={item.date}
                    className="flex-1 flex flex-col items-center h-full justify-end group cursor-pointer relative"
                    onMouseEnter={() => setHoveredDay(item)}
                    onMouseLeave={() => setHoveredDay(null)}
                  >
                    {/* Hover tooltip tooltip atop bar */}
                    {isHovered && (
                      <div className="absolute -top-7 px-2 py-0.5 bg-slate-900 dark:bg-white text-white dark:text-slate-900 text-[10px] font-semibold rounded shadow-lg pointer-events-none whitespace-nowrap z-10">
                        {currentVal.toLocaleString()} {metric === 'messages' ? 'msgs' : 'tok'}
                      </div>
                    )}

                    {/* Bar Pillar */}
                    <div className="w-full max-w-[36px] bg-slate-200 dark:bg-slate-800/80 rounded-t-lg overflow-hidden flex items-end transition-all h-full">
                      <div
                        style={{ height: `${heightPct}%` }}
                        className={`w-full rounded-t-lg transition-all duration-300 ${
                          isToday
                            ? 'bg-indigo-600 dark:bg-indigo-500 shadow-[0_0_12px_rgba(99,102,241,0.5)]'
                            : 'bg-indigo-400/80 dark:bg-indigo-600/70 hover:bg-indigo-500'
                        }`}
                      />
                    </div>

                    {/* Day label */}
                    <span
                      className={`text-[11px] mt-2 font-medium ${
                        isToday
                          ? 'text-indigo-600 dark:text-indigo-400 font-bold'
                          : 'text-slate-500 dark:text-slate-400'
                      }`}
                    >
                      {item.dayLabel}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Model Usage Breakdown Card */}
          <div className="p-3.5 rounded-xl bg-slate-100 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800/80 text-xs">
            <div className="flex items-center gap-1.5 text-slate-700 dark:text-slate-300 font-semibold mb-2">
              <Sparkles className="w-3.5 h-3.5 text-indigo-500" />
              <span>Active Inference Engines</span>
            </div>
            <div className="space-y-1.5 text-slate-600 dark:text-slate-400 text-[11px]">
              <div className="flex justify-between items-center">
                <span>Groq (Llama 3.3 70B & 8B)</span>
                <span className="font-mono text-indigo-600 dark:text-indigo-400 font-medium">Primary · 300+ tok/s</span>
              </div>
              <div className="flex justify-between items-center">
                <span>OpenRouter (GPT-4o & Claude)</span>
                <span className="font-mono text-slate-500">Connected</span>
              </div>
              <div className="flex justify-between items-center">
                <span>Gemini 3.8 Flash</span>
                <span className="font-mono text-slate-500">Direct SDK</span>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-5 py-3 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-lg transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
