import React, { useState, useRef, useEffect } from 'react';
import { motion } from 'framer-motion';
import {
  Film,
  Upload,
  Play,
  Pause,
  Download,
  RotateCcw,
  Sparkles,
  AlertCircle,
  CheckCircle2,
  RefreshCw,
  Video,
  X,
  Maximize2,
  Sliders,
} from 'lucide-react';

interface VideoStudioProps {
  initialPhotoUrl?: string | null;
  initialMimeType?: string;
  onClearInitialPhoto?: () => void;
}

interface VideoHistoryItem {
  id: string;
  videoUrl: string;
  photoUrl: string;
  prompt: string;
  aspectRatio: '16:9' | '9:16';
  timestamp: number;
}

const MOTION_SUGGESTIONS = [
  'Cinematic slow-motion zoom in with soft atmospheric lighting',
  'Gentle breeze blowing through, subtle natural movement and depth',
  'Dynamic drone sweep flying smoothly past the subject',
  'Golden hour lighting shift with shimmering reflections and lens flare',
  'Dramatic 3D parallax camera rotation around the focal point',
];

export const VideoStudio: React.FC<VideoStudioProps> = ({
  initialPhotoUrl,
  initialMimeType = 'image/jpeg',
  onClearInitialPhoto,
}) => {
  const [photoUrl, setPhotoUrl] = useState<string | null>(initialPhotoUrl || null);
  const [photoMimeType, setPhotoMimeType] = useState<string>(initialMimeType);
  const [prompt, setPrompt] = useState<string>('');
  const [aspectRatio, setAspectRatio] = useState<'16:9' | '9:16'>('16:9');

  // Generation state
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [statusMessage, setStatusMessage] = useState<string>('');
  const [progressPercent, setProgressPercent] = useState<number>(0);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Result state
  const [activeVideo, setActiveVideo] = useState<VideoHistoryItem | null>(null);
  const [history, setHistory] = useState<VideoHistoryItem[]>([]);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const pollTimerRef = useRef<any>(null);

  useEffect(() => {
    if (initialPhotoUrl) {
      setPhotoUrl(initialPhotoUrl);
      setPhotoMimeType(initialMimeType || 'image/jpeg');
    }
  }, [initialPhotoUrl, initialMimeType]);

  useEffect(() => {
    return () => {
      if (pollTimerRef.current) {
        clearInterval(pollTimerRef.current);
      }
    };
  }, []);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setPhotoMimeType(file.type || 'image/jpeg');
    const reader = new FileReader();
    reader.onload = (event) => {
      setPhotoUrl(event.target?.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleGenerateVideo = async () => {
    if (!photoUrl) {
      setErrorMessage('Please upload a starting photo to animate.');
      return;
    }

    setIsGenerating(true);
    setErrorMessage(null);
    setStatusMessage('Initiating Veo generation with veo-3.1-fast-generate-preview...');
    setProgressPercent(15);

    try {
      // Step 1: Start Veo video generation operation
      const startRes = await fetch('/api/generate-video', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          image: {
            data: photoUrl,
            mimeType: photoMimeType,
          },
          prompt: prompt || 'Animate this photo with natural, cinematic motion',
          aspectRatio,
        }),
      });

      const startData = await startRes.json();
      if (!startRes.ok || !startData.operationName) {
        throw new Error(startData.error || 'Failed to start video generation.');
      }

      const operationName = startData.operationName;
      setStatusMessage('Veo AI is synthesizing video motion frames (720p)...');
      setProgressPercent(35);

      // Step 2: Poll operation status until complete
      let pollCount = 0;
      const pollInterval = 6000;

      pollTimerRef.current = setInterval(async () => {
        pollCount++;
        setProgressPercent((prev) => Math.min(92, prev + 6));

        try {
          const statusRes = await fetch('/api/video-status', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ operationName }),
          });

          const statusData = await statusRes.json();

          if (statusData.error) {
            clearInterval(pollTimerRef.current);
            throw new Error(statusData.error.message || 'Error occurred during Veo generation');
          }

          if (statusData.done) {
            clearInterval(pollTimerRef.current);
            setStatusMessage('Video synthesized! Downloading MP4 stream...');
            setProgressPercent(95);

            // Step 3: Download video stream
            const downloadRes = await fetch('/api/video-download', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ operationName }),
            });

            if (!downloadRes.ok) {
              const downloadError = await downloadRes.json().catch(() => ({}));
              throw new Error(downloadError.error || 'Failed to download completed video.');
            }

            const videoBlob = await downloadRes.blob();
            const videoObjectUrl = URL.createObjectURL(videoBlob);

            const newItem: VideoHistoryItem = {
              id: `veo-${Date.now()}`,
              videoUrl: videoObjectUrl,
              photoUrl,
              prompt: prompt || 'Cinematic photo motion',
              aspectRatio,
              timestamp: Date.now(),
            };

            setActiveVideo(newItem);
            setHistory((prev) => [newItem, ...prev]);
            setIsGenerating(false);
            setProgressPercent(100);
            setStatusMessage('');
          }
        } catch (pollErr: any) {
          clearInterval(pollTimerRef.current);
          setIsGenerating(false);
          setErrorMessage(pollErr.message || 'Polling error occurred');
        }
      }, pollInterval);
    } catch (err: any) {
      console.error('Video generation error:', err);
      setIsGenerating(false);
      setErrorMessage(err.message || 'Error initiating Veo video animation');
    }
  };

  const togglePlayPause = () => {
    if (!videoRef.current) return;
    if (videoRef.current.paused) {
      videoRef.current.play();
      setIsPlaying(true);
    } else {
      videoRef.current.pause();
      setIsPlaying(false);
    }
  };

  return (
    <div className="h-[calc(100vh-61px)] flex flex-col lg:flex-row overflow-hidden bg-slate-50 dark:bg-slate-950 transition-colors">
      {/* Left Control Panel */}
      <div className="w-full lg:w-[460px] xl:w-[500px] border-b lg:border-b-0 lg:border-r border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 flex flex-col h-full overflow-y-auto">
        {/* Header */}
        <div className="p-5 border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-2.5 mb-1">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-amber-500 to-orange-500 text-white flex items-center justify-center shadow-md shadow-orange-500/20">
              <Film className="w-4 h-4" />
            </div>
            <div>
              <h1 className="font-bold text-base text-slate-900 dark:text-white flex items-center gap-2">
                <span>Veo Video Animator</span>
                <span className="text-[10px] px-2 py-0.5 rounded-full font-medium bg-amber-50 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400 border border-amber-200 dark:border-amber-800">
                  veo-3.1-fast-generate-preview
                </span>
              </h1>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Upload a photo to animate it into a cinematic video with Veo
              </p>
            </div>
          </div>
        </div>

        {/* Form Body */}
        <div className="p-5 flex-1 space-y-5">
          {/* Step 1: Upload Photo */}
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5 flex items-center justify-between">
              <span>1. Upload Starting Photo (Required)</span>
              {photoUrl && (
                <button
                  onClick={() => {
                    setPhotoUrl(null);
                    if (onClearInitialPhoto) onClearInitialPhoto();
                  }}
                  className="text-[10px] text-red-500 hover:underline flex items-center gap-0.5"
                >
                  <X className="w-3 h-3" />
                  <span>Remove</span>
                </button>
              )}
            </label>

            <input
              type="file"
              ref={fileInputRef}
              accept="image/*"
              onChange={handleFileUpload}
              className="hidden"
            />

            {photoUrl ? (
              <div className="relative rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-700 group bg-slate-900">
                <img
                  src={photoUrl}
                  alt="Starting photo for animation"
                  className="w-full h-44 object-cover"
                />
                <div className="absolute inset-0 bg-slate-950/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                  <button
                    onClick={() => fileInputRef.current?.click()}
                    className="px-3 py-1.5 rounded-xl bg-white text-slate-800 text-xs font-semibold shadow-md flex items-center gap-1.5 hover:bg-slate-100"
                  >
                    <Upload className="w-3.5 h-3.5" />
                    <span>Change Photo</span>
                  </button>
                </div>
              </div>
            ) : (
              <button
                onClick={() => fileInputRef.current?.click()}
                className="w-full h-36 border-2 border-dashed border-slate-300 dark:border-slate-700 rounded-2xl flex flex-col items-center justify-center p-4 hover:border-amber-500 hover:bg-amber-50/30 dark:hover:bg-amber-950/20 transition-all text-slate-500 dark:text-slate-400 group cursor-pointer"
              >
                <Upload className="w-7 h-7 mb-2 text-slate-400 group-hover:text-amber-500 transition-colors" />
                <span className="text-xs font-semibold text-slate-700 dark:text-slate-200">
                  Select a photo to bring to life
                </span>
                <span className="text-[10px] text-slate-400 mt-0.5">
                  JPG, PNG, WebP supported
                </span>
              </button>
            )}
          </div>

          {/* Step 2: Aspect Ratio (Strictly 16:9 or 9:16 per requirement) */}
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
              2. Video Aspect Ratio
            </label>
            <div className="grid grid-cols-2 gap-2">
              <motion.button
                whileHover={{ scale: 1.03 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setAspectRatio('16:9')}
                className={`p-3 rounded-2xl border text-left transition-all cursor-pointer ${
                  aspectRatio === '16:9'
                    ? 'border-amber-500 bg-amber-50 dark:bg-amber-950/50 text-amber-800 dark:text-amber-300 shadow-xs'
                    : 'border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 text-slate-600 dark:text-slate-400 hover:bg-slate-100'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="font-bold text-xs">16:9 Landscape</span>
                  <div className="w-6 h-3.5 border-2 border-current rounded-xs opacity-70" />
                </div>
                <p className="text-[10px] text-slate-400">Desktop, YouTube, TV</p>
              </motion.button>

              <motion.button
                whileHover={{ scale: 1.03 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setAspectRatio('9:16')}
                className={`p-3 rounded-2xl border text-left transition-all cursor-pointer ${
                  aspectRatio === '9:16'
                    ? 'border-amber-500 bg-amber-50 dark:bg-amber-950/50 text-amber-800 dark:text-amber-300 shadow-xs'
                    : 'border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 text-slate-600 dark:text-slate-400 hover:bg-slate-100'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="font-bold text-xs">9:16 Portrait</span>
                  <div className="w-3.5 h-6 border-2 border-current rounded-xs opacity-70" />
                </div>
                <p className="text-[10px] text-slate-400">Reels, TikTok, Shorts</p>
              </motion.button>
            </div>
          </div>

          {/* Step 3: Motion Guidance Prompt */}
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
              3. Motion Guidance (Optional)
            </label>
            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="e.g. Cinematic slow motion zoom with shimmering water reflections and ambient lighting..."
              rows={3}
              className="w-full text-xs p-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-800/50 text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500 transition-all resize-none"
            />

            {/* Suggestions */}
            <div className="mt-2">
              <span className="text-[11px] font-semibold text-slate-500 dark:text-slate-400 flex items-center gap-1 mb-1.5">
                <Sparkles className="w-3 h-3 text-amber-500" />
                <span>Motion ideas:</span>
              </span>
              <div className="flex flex-wrap gap-1.5">
                {MOTION_SUGGESTIONS.slice(0, 3).map((item, idx) => (
                  <motion.button
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.96 }}
                    key={idx}
                    onClick={() => setPrompt(item)}
                    className="text-[10px] text-left p-1.5 px-2 rounded-lg bg-slate-100 dark:bg-slate-800/80 hover:bg-amber-50 dark:hover:bg-amber-950/40 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700 hover:border-amber-300 dark:hover:border-amber-800 transition-colors line-clamp-1 cursor-pointer"
                  >
                    &ldquo;{item}&rdquo;
                  </motion.button>
                ))}
              </div>
            </div>
          </div>

          {/* Error Notice */}
          {errorMessage && (
            <div className="p-3 rounded-xl bg-red-50 dark:bg-red-950/50 border border-red-200 dark:border-red-900/60 text-xs text-red-600 dark:text-red-400 flex items-start gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
              <div>
                <p className="font-semibold">Veo Video Notice</p>
                <p className="text-[11px] mt-0.5">{errorMessage}</p>
              </div>
            </div>
          )}

          {/* Progress Indicator */}
          {isGenerating && (
            <div className="p-4 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900/60 space-y-2.5">
              <div className="flex items-center justify-between text-xs">
                <span className="font-semibold text-amber-800 dark:text-amber-300 flex items-center gap-1.5">
                  <RefreshCw className="w-3.5 h-3.5 animate-spin text-amber-600" />
                  <span>{statusMessage}</span>
                </span>
                <span className="font-mono text-amber-600 font-bold">{progressPercent}%</span>
              </div>
              <div className="w-full h-2 rounded-full bg-amber-200/60 dark:bg-amber-900/40 overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-amber-500 to-orange-500 rounded-full transition-all duration-500"
                  style={{ width: `${progressPercent}%` }}
                />
              </div>
              <p className="text-[10px] text-amber-700/80 dark:text-amber-400/80 italic">
                Veo generates high-fidelity 720p motion video. This may take ~45–60 seconds.
              </p>
            </div>
          )}

          {/* Generate Button */}
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.96 }}
            onClick={handleGenerateVideo}
            disabled={isGenerating || !photoUrl}
            className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 disabled:opacity-50 text-white font-semibold text-xs shadow-md shadow-orange-500/20 transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            {isGenerating ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" />
                <span>Synthesizing Video with Veo...</span>
              </>
            ) : (
              <>
                <Film className="w-4 h-4" />
                <span>Animate Photo into Video</span>
              </>
            )}
          </motion.button>
        </div>
      </div>

      {/* Right Canvas: Video Player & Output Display */}
      <div className="flex-1 p-6 overflow-y-auto flex flex-col items-center justify-start">
        {activeVideo ? (
          <div className="w-full max-w-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl shadow-xl overflow-hidden animate-fade-in">
            {/* Top Bar */}
            <div className="p-4 px-6 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-amber-50 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400 border border-amber-200 dark:border-amber-800">
                  Veo 3.1 Fast Preview • {activeVideo.aspectRatio}
                </span>
                <p className="text-xs text-slate-700 dark:text-slate-300 font-medium mt-1 line-clamp-1">
                  &ldquo;{activeVideo.prompt}&rdquo;
                </p>
              </div>

              <div className="flex items-center gap-1.5">
                <motion.a
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.94 }}
                  href={activeVideo.videoUrl}
                  download={`veo-animation-${activeVideo.id}.mp4`}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-white text-xs font-semibold shadow-xs transition-colors cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download MP4</span>
                </motion.a>
              </div>
            </div>

            {/* Video Player Display */}
            <div className="p-6 bg-slate-950 flex items-center justify-center min-h-[360px]">
              <video
                ref={videoRef}
                src={activeVideo.videoUrl}
                controls
                autoPlay
                loop
                playsInline
                className={`rounded-2xl max-h-[480px] shadow-2xl ${
                  activeVideo.aspectRatio === '9:16' ? 'w-auto h-[460px]' : 'w-full h-auto'
                }`}
              />
            </div>

            {/* Comparison Bar: Starting Photo vs Generated Video */}
            <div className="p-4 px-6 bg-slate-50 dark:bg-slate-950/50 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-xl overflow-hidden border border-slate-200 dark:border-slate-700 shrink-0">
                  <img
                    src={activeVideo.photoUrl}
                    alt="Starting photo"
                    className="w-full h-full object-cover"
                  />
                </div>
                <div>
                  <p className="text-xs font-semibold text-slate-800 dark:text-slate-200">
                    Source Photo Animated
                  </p>
                  <p className="text-[10px] text-slate-400">
                    720p HD Render • Model: veo-3.1-fast-generate-preview
                  </p>
                </div>
              </div>

              <motion.button
                whileHover={{ scale: 1.08 }}
                whileTap={{ scale: 0.9, rotate: -45 }}
                onClick={() => {
                  if (videoRef.current) {
                    videoRef.current.currentTime = 0;
                    videoRef.current.play();
                  }
                }}
                className="flex items-center gap-1.5 text-xs text-amber-600 hover:text-amber-700 font-semibold cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Replay</span>
              </motion.button>
            </div>
          </div>
        ) : (
          /* Empty State */
          <div className="max-w-md my-auto text-center p-8 border border-dashed border-slate-300 dark:border-slate-800 rounded-3xl">
            <div className="w-14 h-14 rounded-2xl bg-amber-50 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400 flex items-center justify-center mx-auto mb-3 shadow-sm">
              <Video className="w-7 h-7" />
            </div>
            <h3 className="font-bold text-slate-800 dark:text-slate-200 text-sm">
              Video Canvas Ready
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              Upload a starting photo on the left, select your aspect ratio (16:9 landscape or 9:16 portrait), and let Veo animate it into video.
            </p>
          </div>
        )}

        {/* History of Generated Videos */}
        {history.length > 1 && (
          <div className="w-full max-w-2xl mt-8">
            <h4 className="text-xs font-bold text-slate-700 dark:text-slate-300 mb-3 flex items-center gap-1.5">
              <Film className="w-3.5 h-3.5 text-amber-500" />
              <span>Recent Videos in This Session</span>
            </h4>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {history.map((item) => (
                <div
                  key={item.id}
                  onClick={() => setActiveVideo(item)}
                  className={`group relative rounded-2xl overflow-hidden border cursor-pointer aspect-video bg-slate-900 transition-all ${
                    activeVideo?.id === item.id
                      ? 'ring-2 ring-amber-500 border-transparent shadow-md'
                      : 'border-slate-200 dark:border-slate-800 hover:opacity-90'
                  }`}
                >
                  <video
                    src={item.videoUrl}
                    className="w-full h-full object-cover"
                    muted
                  />
                  <div className="absolute inset-0 bg-slate-950/50 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                    <Play className="w-6 h-6 text-white" />
                  </div>
                  <div className="absolute bottom-1.5 left-2 right-2 text-[10px] text-white truncate font-medium drop-shadow-md">
                    {item.prompt}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
