import React, { createContext, useContext, useEffect, useState } from 'react';

export interface UserProfile {
  name: string;
  email: string;
  avatar?: string;
}

export interface AiConfig {
  name: string;
  avatarIcon?: string;
}

interface AuthContextType {
  user: UserProfile | null;
  isLoggedIn: boolean;
  aiConfig: AiConfig;
  login: (userData: UserProfile, customAiName?: string) => void;
  logout: () => void;
  setAiName: (newName: string) => void;
  updateUser: (userData: Partial<UserProfile>) => void;
}

const USER_STORAGE_KEY = 'nova_ai_auth_user_v1';
const AI_CONFIG_KEY = 'nova_ai_config_v1';

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<UserProfile | null>(() => {
    try {
      const stored = localStorage.getItem(USER_STORAGE_KEY);
      if (stored) return JSON.parse(stored);
    } catch {}
    return null;
  });

  const [aiConfig, setAiConfig] = useState<AiConfig>(() => {
    try {
      const stored = localStorage.getItem(AI_CONFIG_KEY);
      if (stored) return JSON.parse(stored);
    } catch {}
    return { name: 'Nova AI' };
  });

  const isLoggedIn = user !== null;

  useEffect(() => {
    try {
      if (user) {
        localStorage.setItem(USER_STORAGE_KEY, JSON.stringify(user));
      } else {
        localStorage.removeItem(USER_STORAGE_KEY);
      }
    } catch {}
  }, [user]);

  useEffect(() => {
    try {
      localStorage.setItem(AI_CONFIG_KEY, JSON.stringify(aiConfig));
    } catch {}
  }, [aiConfig]);

  const login = (userData: UserProfile, customAiName?: string) => {
    setUser(userData);
    if (customAiName && customAiName.trim()) {
      setAiConfig((prev) => ({ ...prev, name: customAiName.trim() }));
    }
  };

  const logout = () => {
    setUser(null);
  };

  const setAiName = (newName: string) => {
    if (!newName.trim()) return;
    setAiConfig((prev) => ({ ...prev, name: newName.trim() }));
  };

  const updateUser = (userData: Partial<UserProfile>) => {
    setUser((prev) => (prev ? { ...prev, ...userData } : null));
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        isLoggedIn,
        aiConfig,
        login,
        logout,
        setAiName,
        updateUser,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
