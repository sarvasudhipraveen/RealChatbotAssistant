import React, { createContext, useContext, useEffect, useState } from 'react';

export type Theme = 'warm-espresso' | 'warm-amber' | 'warm-sunset' | 'dark' | 'light';

export interface ThemeOption {
  id: Theme;
  name: string;
  category: 'warm' | 'classic';
  description: string;
  previewBg: string;
  previewAccent: string;
  isDark: boolean;
}

export const THEME_OPTIONS: ThemeOption[] = [
  {
    id: 'warm-espresso',
    name: 'Warm Espresso',
    category: 'warm',
    description: 'Roasted dark mocha with golden caramel & honey amber glow',
    previewBg: '#171210',
    previewAccent: '#f59e0b',
    isDark: true,
  },
  {
    id: 'warm-amber',
    name: 'Warm Amber Sand',
    category: 'warm',
    description: 'Sunlit cream, sandstone linen, and warm terracotta accents',
    previewBg: '#faf6ee',
    previewAccent: '#d97706',
    isDark: false,
  },
  {
    id: 'warm-sunset',
    name: 'Sunset Terracotta',
    category: 'warm',
    description: 'Dusk rose, fiery sunset copper, and cozy embers',
    previewBg: '#1b1214',
    previewAccent: '#ea580c',
    isDark: true,
  },
  {
    id: 'dark',
    name: 'Midnight Slate',
    category: 'classic',
    description: 'Crisp cool dark slate with indigo accents',
    previewBg: '#020617',
    previewAccent: '#6366f1',
    isDark: true,
  },
  {
    id: 'light',
    name: 'Clean Canvas',
    category: 'classic',
    description: 'Minimalist neutral white and soft cool gray',
    previewBg: '#ffffff',
    previewAccent: '#4f46e5',
    isDark: false,
  },
];

interface ThemeContextType {
  theme: Theme;
  isDark: boolean;
  toggleTheme: () => void;
  setTheme: (theme: Theme) => void;
  availableThemes: ThemeOption[];
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

export const ThemeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [theme, setThemeState] = useState<Theme>(() => {
    try {
      const saved = localStorage.getItem('nova_ai_theme') as Theme;
      if (
        saved === 'warm-espresso' ||
        saved === 'warm-amber' ||
        saved === 'warm-sunset' ||
        saved === 'dark' ||
        saved === 'light'
      ) {
        return saved;
      }
    } catch {}
    // Default to the signature cozy Warm Espresso theme
    return 'warm-espresso';
  });

  const currentOption = THEME_OPTIONS.find((t) => t.id === theme) || THEME_OPTIONS[0];
  const isDark = currentOption.isDark;

  useEffect(() => {
    try {
      localStorage.setItem('nova_ai_theme', theme);
    } catch {}

    const root = document.documentElement;
    root.setAttribute('data-theme', theme);
    root.style.colorScheme = isDark ? 'dark' : 'light';

    // Remove old theme classes
    root.classList.remove(
      'dark',
      'light',
      'theme-warm-espresso',
      'theme-warm-amber',
      'theme-warm-sunset'
    );
    document.body.classList.remove(
      'dark',
      'light',
      'theme-warm-espresso',
      'theme-warm-amber',
      'theme-warm-sunset'
    );

    // Apply dark/light core class
    if (isDark) {
      root.classList.add('dark');
      document.body.classList.add('dark');
    } else {
      root.classList.add('light');
      document.body.classList.add('light');
    }

    // Apply specific theme class
    root.classList.add(`theme-${theme}`);
    document.body.classList.add(`theme-${theme}`);
  }, [theme, isDark]);

  const toggleTheme = () => {
    setThemeState((prev) => {
      // Toggle between warm dark (espresso) and warm light (amber sand)
      if (prev === 'warm-espresso' || prev === 'warm-sunset' || prev === 'dark') {
        return 'warm-amber';
      }
      return 'warm-espresso';
    });
  };

  const setTheme = (newTheme: Theme) => {
    setThemeState(newTheme);
  };

  return (
    <ThemeContext.Provider
      value={{
        theme,
        isDark,
        toggleTheme,
        setTheme,
        availableThemes: THEME_OPTIONS,
      }}
    >
      {children}
    </ThemeContext.Provider>
  );
};

export const useTheme = () => {
  const context = useContext(ThemeContext);
  if (!context) {
    throw new Error('useTheme must be used within a ThemeProvider');
  }
  return context;
};
