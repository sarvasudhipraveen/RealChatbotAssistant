export interface FileAttachment {
  id: string;
  name: string;
  type: string; // mimeType
  size: number;
  dataUrl: string; // base64 data url for images or files
  isImage: boolean;
  textContent?: string; // extracted text for text/code/csv files
}

export interface GroundingChunk {
  web?: {
    uri: string;
    title: string;
  };
}

export interface GroundingMetadata {
  webSearchQueries?: string[];
  searchChunks?: GroundingChunk[];
  groundingSupports?: any[];
}

export interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: number;
  status: 'idle' | 'streaming' | 'complete' | 'error';
  error?: string;
  latencyMs?: number;
  attachments?: FileAttachment[];
  groundingMetadata?: GroundingMetadata;
}

export interface Persona {
  id: string;
  name: string;
  roleTitle: string;
  description: string;
  systemPrompt: string;
  initialMessage: string;
  category: 'general' | 'creative' | 'productivity' | 'learning';
  suggestedPrompts: string[];
}

export interface ChatSession {
  id: string;
  title: string;
  createdAt: number;
  updatedAt: number;
  personaId: string;
  systemInstruction?: string;
  temperature: number;
  model?: string;
  useGoogleSearch?: boolean;
  messages: Message[];
}
