export interface DayUsage {
  date: string; // YYYY-MM-DD
  dayLabel: string; // Mon, Tue, etc.
  messages: number;
  tokens: number;
}

const STORAGE_KEY = 'nova_ai_daily_usage_v1';

// Generate last 7 days with realistic starting mock + real accumulation
export function getDailyUsage(): DayUsage[] {
  const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  const today = new Date();
  
  let stored: Record<string, { messages: number; tokens: number }> = {};
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) stored = JSON.parse(raw);
  } catch (e) {
    stored = {};
  }

  // Base seed if completely empty
  const defaultSeeds: Record<number, { messages: number; tokens: number }> = {
    6: { messages: 18, tokens: 4200 }, // 6 days ago
    5: { messages: 32, tokens: 7800 },
    4: { messages: 45, tokens: 11200 },
    3: { messages: 28, tokens: 6900 },
    2: { messages: 54, tokens: 14500 },
    1: { messages: 68, tokens: 18200 }, // yesterday
    0: { messages: 22, tokens: 5300 },  // today
  };

  const result: DayUsage[] = [];

  for (let i = 6; i >= 0; i--) {
    const d = new Date(today);
    d.setDate(today.getDate() - i);
    const dateStr = d.toISOString().split('T')[0];
    const dayLabel = days[d.getDay()];

    const saved = stored[dateStr];
    const seed = defaultSeeds[i] || { messages: 10, tokens: 2500 };

    result.push({
      date: dateStr,
      dayLabel,
      messages: saved ? saved.messages : seed.messages,
      tokens: saved ? saved.tokens : seed.tokens,
    });
  }

  return result;
}

export function recordMessageUsage(messageLength: number) {
  const dateStr = new Date().toISOString().split('T')[0];
  let stored: Record<string, { messages: number; tokens: number }> = {};
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) stored = JSON.parse(raw);
  } catch (e) {
    stored = {};
  }

  // Approx 1 token per 4 chars of user prompt + generated response
  const estimatedTokens = Math.max(25, Math.round(messageLength / 3.5));

  if (!stored[dateStr]) {
    stored[dateStr] = { messages: 1, tokens: estimatedTokens };
  } else {
    stored[dateStr].messages += 1;
    stored[dateStr].tokens += estimatedTokens;
  }

  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(stored));
  } catch (e) {
    // ignore
  }
}
