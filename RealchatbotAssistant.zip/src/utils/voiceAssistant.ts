// Voice Assistant helper for Speech Synthesis and Speech Recognition

export interface VoiceSettings {
  autoSpeak: boolean;
  rate: number;
  pitch: number;
  voiceIndex: number;
}

const VOICE_SETTINGS_KEY = 'nova_ai_voice_settings_v1';

export function getStoredVoiceSettings(): VoiceSettings {
  try {
    const raw = localStorage.getItem(VOICE_SETTINGS_KEY);
    if (raw) return JSON.parse(raw);
  } catch {}
  return {
    autoSpeak: false,
    rate: 1.0,
    pitch: 1.0,
    voiceIndex: 0,
  };
}

export function saveStoredVoiceSettings(settings: VoiceSettings) {
  try {
    localStorage.setItem(VOICE_SETTINGS_KEY, JSON.stringify(settings));
  } catch {}
}

let activeUtterance: SpeechSynthesisUtterance | null = null;

export function stopSpeaking() {
  if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
    window.speechSynthesis.cancel();
    activeUtterance = null;
  }
}

export function speakText(
  text: string,
  settings?: Partial<VoiceSettings>,
  onStart?: () => void,
  onEnd?: () => void,
  onError?: (err: any) => void
) {
  if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
    onError?.(new Error('Speech synthesis not supported on this browser'));
    return;
  }

  // Cancel any ongoing speech
  stopSpeaking();

  // Strip markdown formatting for cleaner speech
  const cleanText = text
    .replace(/```[\s\S]*?```/g, 'Code block omitted.')
    .replace(/`([^`]+)`/g, '$1')
    .replace(/[*_#~>]/g, '')
    .replace(/\[([^\]]+)\]\([^\)]+\)/g, '$1')
    .trim();

  if (!cleanText) return;

  const currentSettings = { ...getStoredVoiceSettings(), ...settings };
  const utterance = new SpeechSynthesisUtterance(cleanText);
  utterance.rate = currentSettings.rate || 1.0;
  utterance.pitch = currentSettings.pitch || 1.0;

  const voices = window.speechSynthesis.getVoices();
  if (voices.length > 0) {
    // Prefer natural English voices like Google US English, Samantha, etc.
    const preferredVoice =
      voices.find((v) => v.name.includes('Natural') || v.name.includes('Google') || v.name.includes('Samantha')) ||
      voices.find((v) => v.lang.startsWith('en')) ||
      voices[0];

    if (preferredVoice) {
      utterance.voice = preferredVoice;
    }
  }

  utterance.onstart = () => {
    onStart?.();
  };

  utterance.onend = () => {
    activeUtterance = null;
    onEnd?.();
  };

  utterance.onerror = (e) => {
    activeUtterance = null;
    onError?.(e);
  };

  activeUtterance = utterance;
  window.speechSynthesis.speak(utterance);
}

// Speech recognition helper
export function createSpeechRecognition(): any | null {
  if (typeof window === 'undefined') return null;
  const SpeechRecognition =
    (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
  if (!SpeechRecognition) return null;

  const recognition = new SpeechRecognition();
  recognition.continuous = false;
  recognition.interimResults = true;
  recognition.lang = 'en-US';
  return recognition;
}
